import { cn } from "../../utils/cn";
import { useEffect } from "react";
import type { ReactNode } from "react";

export function Sheet({
  open,
  onClose,
  title,
  children,
  side = "bottom",
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
  side?: "bottom" | "right";
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex" role="dialog" aria-modal="true" aria-label={title}>
      <button
        aria-label="Close"
        onClick={onClose}
        className="absolute inset-0 bg-[#080c1c]/72 backdrop-blur-sm"
      />
      <div
        className={cn(
          "sa-grid-bg relative z-10 flex flex-col border-[var(--sa-line)] sa-reveal",
          side === "bottom"
            ? "mt-auto max-h-[88vh] w-full rounded-t-[var(--sa-r-xl)] border-t-2"
            : "ml-auto h-full w-[min(430px,92vw)] border-l-2"
        )}
      >
        {side === "bottom" && (
          <div className="mx-auto mt-3 h-1.5 w-12 rounded-full bg-[var(--sa-bg-4)]" />
        )}
        <div className="flex items-center justify-between gap-2 px-5 pb-3 pt-4">
          {title && <h3 className="sa-display text-[20px] text-[var(--sa-text-hi)]">{title}</h3>}
          <button
            onClick={onClose}
            aria-label="Close"
            className="ml-auto grid h-10 w-10 shrink-0 place-items-center rounded-full border-2 border-[var(--sa-line)] bg-[var(--sa-bg-2)] text-[var(--sa-text)] transition-transform hover:text-white active:scale-90"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round">
              <path d="M18 6L6 18M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="overflow-y-auto px-5 pb-8">{children}</div>
      </div>
    </div>
  );
}

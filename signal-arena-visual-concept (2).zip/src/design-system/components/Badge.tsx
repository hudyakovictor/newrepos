import { cn } from "../../utils/cn";
import type { ReactNode } from "react";

type Tone = "signal" | "noise" | "danger" | "neutral" | "info" | "locked" | "gold";

/* Tinted dark chips — readable, low-glare, no candy gradients. */
const tones: Record<Tone, string> = {
  signal: "text-[var(--sa-signal)] bg-[var(--sa-signal)]/12 border-[var(--sa-signal)]/35",
  gold: "text-[var(--sa-gold)] bg-[var(--sa-gold)]/12 border-[var(--sa-gold)]/35",
  noise: "text-[var(--sa-noise)] bg-[var(--sa-noise)]/12 border-[var(--sa-noise)]/35",
  danger: "text-[var(--sa-danger)] bg-[var(--sa-danger)]/12 border-[var(--sa-danger)]/35",
  info: "text-[var(--sa-academy)] bg-[var(--sa-academy)]/12 border-[var(--sa-academy)]/35",
  neutral: "text-[var(--sa-text)] bg-[var(--sa-bg-2)] border-[var(--sa-line-hi)]",
  locked: "text-[var(--sa-text-dim)] bg-[var(--sa-bg-2)] border-[var(--sa-line)]",
};

export function Badge({
  tone = "neutral",
  children,
  className,
  icon,
}: {
  tone?: Tone;
  children: ReactNode;
  className?: string;
  icon?: ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-[var(--sa-r-pill)] border px-2.5 py-[3px]",
        "font-[var(--sa-font-display)] text-[11.5px] font-extrabold leading-tight",
        tones[tone],
        className
      )}
    >
      {icon && <span className="[&_svg]:h-3.5 [&_svg]:w-3.5">{icon}</span>}
      {children}
    </span>
  );
}

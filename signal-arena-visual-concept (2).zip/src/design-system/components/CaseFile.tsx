import { cn } from "../../utils/cn";
import type { ReactNode } from "react";

/* Rubber stamp — outline type in a rotated ruled box.
 * Used for verdicts: SEALED, VALIDATED, CLASSIFIED, UNCONFIRMED. */
export function Stamp({
  children,
  tone = "gold",
  size = "md",
  className,
  animate,
}: {
  children: ReactNode;
  tone?: "gold" | "signal" | "danger" | "muted";
  size?: "sm" | "md" | "lg";
  className?: string;
  animate?: boolean;
}) {
  const colors: Record<string, string> = {
    gold: "var(--sa-gold)",
    signal: "var(--sa-signal)",
    danger: "var(--sa-danger)",
    muted: "var(--sa-text-faint)",
  };
  const c = colors[tone];
  const pad = size === "lg" ? "px-4 py-2" : size === "sm" ? "px-2 py-0.5" : "px-3 py-1.5";
  const text = size === "lg" ? "text-[17px]" : size === "sm" ? "text-[9px]" : "text-[12px]";

  return (
    <span
      className={cn(
        "sa-display inline-block -rotate-[9deg] select-none rounded-[3px] border-2 uppercase leading-none tracking-[0.12em]",
        pad,
        text,
        animate && "sa-stamp",
        className
      )}
      style={{ color: c, borderColor: c, opacity: 0.92 }}
    >
      {children}
    </span>
  );
}

/* Evidence tag — a punched paper label clipped to a record. */
export function EvidenceTag({
  children,
  tone,
  className,
}: {
  children: ReactNode;
  tone?: string;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "sa-label relative inline-flex items-center gap-1.5 rounded-[3px] border py-1 pl-4 pr-2",
        className
      )}
      style={{
        color: tone ?? "var(--sa-text-dim)",
        borderColor: tone ? `${tone}55` : "var(--sa-line-hi)",
        background: tone ? `${tone}12` : "var(--sa-bg-2)",
      }}
    >
      {/* punch hole */}
      <span
        aria-hidden
        className="absolute left-1.5 h-[5px] w-[5px] rounded-full border"
        style={{ borderColor: tone ?? "var(--sa-line-hi)" }}
      />
      {children}
    </span>
  );
}

/* Dashed ledger rule with an optional inline caption. */
export function Rule({ label, className }: { label?: string; className?: string }) {
  if (!label) return <div className={cn("sa-rule", className)} />;
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <span className="sa-label shrink-0 text-[var(--sa-text-faint)]">{label}</span>
      <span className="sa-rule flex-1" />
    </div>
  );
}

/* Signal vs Noise meter — the product's core idea made visible.
 * Two opposed bars from a shared centre. Values are printed, so the
 * reading never depends on colour alone. */
export function SignalNoiseBar({
  signal,
  noise,
  className,
}: {
  signal: number;
  noise: number;
  className?: string;
}) {
  const total = Math.max(1, signal + noise);
  const sPct = (signal / total) * 100;
  const nPct = (noise / total) * 100;
  return (
    <div className={cn("w-full", className)}>
      <div className="mb-1.5 flex items-baseline justify-between">
        <span className="sa-label text-[var(--sa-signal)]">Signal {signal}</span>
        <span className="sa-label text-[var(--sa-noise)]">Noise {noise}</span>
      </div>
      <div
        className="flex h-2.5 w-full overflow-hidden rounded-[2px] border border-[var(--sa-line-soft)] bg-[var(--sa-plate)]"
        role="img"
        aria-label={`Signal ${signal}, noise ${noise}`}
      >
        <div
          className="h-full"
          style={{
            width: `${sPct}%`,
            background:
              "repeating-linear-gradient(90deg, var(--sa-signal) 0 3px, var(--sa-signal-2) 3px 6px)",
          }}
        />
        <div
          className="h-full"
          style={{
            width: `${nPct}%`,
            background:
              "repeating-linear-gradient(90deg, var(--sa-noise) 0 3px, var(--sa-noise-2) 3px 6px)",
          }}
        />
      </div>
    </div>
  );
}

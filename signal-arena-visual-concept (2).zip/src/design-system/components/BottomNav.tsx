import { cn } from "../../utils/cn";
import { Icon } from "./icons";
import type { ReactElement } from "react";

/* Exactly five canonical root sections. Never add a sixth. */
export type RootSection = "hub" | "academy" | "arena" | "shop" | "tournament";

const items: { id: RootSection; label: string; Icon: () => ReactElement; c: string }[] = [
  { id: "hub", label: "Hub", Icon: Icon.hub, c: "var(--sa-hub)" },
  { id: "academy", label: "Academy", Icon: Icon.academy, c: "var(--sa-academy)" },
  { id: "arena", label: "Arena", Icon: Icon.arena, c: "var(--sa-arena)" },
  { id: "shop", label: "Shop", Icon: Icon.shop, c: "var(--sa-shop)" },
  { id: "tournament", label: "Tournaments", Icon: Icon.tournament, c: "var(--sa-cups)" },
];

export function BottomNav({
  active,
  onChange,
}: {
  active: RootSection;
  onChange: (id: RootSection) => void;
}) {
  return (
    <nav
      aria-label="Primary"
      className="sticky bottom-0 z-30 border-t border-[var(--sa-line)] bg-[var(--sa-plate)]/95 backdrop-blur-xl"
    >
      <ul className="mx-auto flex max-w-[520px] items-stretch justify-around gap-0.5 px-1.5 pb-[max(env(safe-area-inset-bottom),8px)] pt-1.5">
        {items.map((it) => {
          const on = it.id === active;
          const IconCmp = it.Icon;
          return (
            <li key={it.id} className="min-w-0 flex-1">
              <button
                onClick={() => onChange(it.id)}
                aria-current={on ? "page" : undefined}
                className={cn(
                  "flex min-h-[54px] w-full flex-col items-center justify-center gap-1 rounded-[var(--sa-r-md)] px-0.5 py-1.5",
                  "transition-transform duration-[var(--sa-t-base)] active:scale-95"
                )}
              >
                <span
                  className="grid h-8 w-8 place-items-center rounded-[var(--sa-r-sm)] transition-colors duration-[var(--sa-t-base)] [&_svg]:h-[19px] [&_svg]:w-[19px]"
                  style={
                    on
                      ? { background: it.c, color: "#05070d" }
                      : { color: "var(--sa-text-dim)" }
                  }
                >
                  <IconCmp />
                </span>
                <span
                  className="w-full truncate text-center text-[9.5px] font-extrabold leading-none"
                  style={{ color: on ? it.c : "var(--sa-text-faint)" }}
                >
                  {it.label}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

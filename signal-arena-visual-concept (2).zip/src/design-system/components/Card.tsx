import { cn } from "../../utils/cn";
import type { HTMLAttributes, ReactNode } from "react";

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  accent?: string;
  interactive?: boolean;
  flat?: boolean;
  /** One-shot glow on mount. Animation only — never a resting glow. */
  pulse?: boolean;
}

/* Card — dark plate with a hairline and a 2px accent rail on top. */
export function Card({
  accent,
  interactive,
  flat,
  pulse,
  className,
  children,
  style,
  ...props
}: CardProps) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-[var(--sa-r-lg)] border border-[var(--sa-line)]",
        "bg-gradient-to-b from-[var(--sa-card-hi)] to-[var(--sa-card)]",
        !flat && "shadow-[var(--sa-shadow-card)]",
        interactive &&
          "cursor-pointer transition-[transform,border-color] duration-[var(--sa-t-base)] hover:-translate-y-0.5 hover:border-[var(--sa-line-hi)] active:translate-y-0",
        pulse && "sa-glow-once",
        className
      )}
      style={
        {
          ...(pulse && accent ? { ["--sa-glow-c" as string]: accent } : {}),
          ...style,
        } as React.CSSProperties
      }
      {...props}
    >
      <span aria-hidden className="pointer-events-none absolute inset-x-0 top-0 h-px bg-white/5" />
      {accent && (
        <span
          aria-hidden
          className="absolute inset-x-0 top-0 h-[2px]"
          style={{ background: accent, opacity: 0.9 }}
        />
      )}
      {children}
    </div>
  );
}

export function CardBody({ className, children }: { className?: string; children: ReactNode }) {
  return <div className={cn("p-4", className)}>{children}</div>;
}

/* Plate — recessed well for dense lists and read-only data. */
export function Plate({
  className,
  children,
  accent,
}: {
  className?: string;
  children: ReactNode;
  accent?: string;
}) {
  return (
    <div
      className={cn(
        "rounded-[var(--sa-r-md)] border border-[var(--sa-line-soft)] bg-[var(--sa-plate)]",
        "shadow-[inset_0_1px_3px_rgba(0,0,0,0.6)]",
        className
      )}
      style={accent ? { borderLeftColor: accent, borderLeftWidth: 2 } : undefined}
    >
      {children}
    </div>
  );
}

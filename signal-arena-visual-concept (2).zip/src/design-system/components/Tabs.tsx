import { cn } from "../../utils/cn";

export interface TabItem {
  id: string;
  label: string;
}

export function Tabs({
  items,
  active,
  onChange,
  className,
}: {
  items: TabItem[];
  active: string;
  onChange: (id: string) => void;
  className?: string;
}) {
  return (
    <div
      role="tablist"
      className={cn(
        "flex gap-1.5 overflow-x-auto rounded-[var(--sa-r-md)] border-2 border-[var(--sa-line)] bg-[var(--sa-bg-0)]/60 p-1.5",
        className
      )}
    >
      {items.map((t) => {
        const isActive = t.id === active;
        return (
          <button
            key={t.id}
            role="tab"
            aria-selected={isActive}
            onClick={() => onChange(t.id)}
            className={cn(
              "sa-display min-h-[40px] flex-1 whitespace-nowrap rounded-[var(--sa-r-sm)] px-3 text-[13px]",
              "transition-all duration-[var(--sa-t-fast)] active:scale-95",
              isActive
                ? "bg-gradient-to-b from-[var(--sa-bg-4)] to-[var(--sa-bg-3)] text-white shadow-[0_3px_0_rgba(0,0,0,0.35)]"
                : "text-[var(--sa-text-dim)] hover:text-[var(--sa-text)]"
            )}
          >
            {t.label}
          </button>
        );
      })}
    </div>
  );
}

import { useEffect, useState, useCallback } from "react";
import { cn } from "../../utils/cn";
import type { ReactNode } from "react";

export interface EntityVisual {
  id: string;
  name: string;
  slug: string;
  distortion: string;
  accent: string;
  quote: string;
  observed: string;
  tell: string;
  counter: string;
  threat: number;
  encounters: number;
  cost: string;
  art: string;
  seen?: boolean;
}

/* ---------------------------------------------------------------
 * SpecimenImage — entity art with an intentional fallback.
 * The art is referenced from the provided baseline repository. If it
 * cannot load, we render a containment plate rather than a broken box.
 * ------------------------------------------------------------- */
function SpecimenImage({
  entity,
  className,
}: {
  entity: EntityVisual;
  className?: string;
}) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div
        className={cn("relative grid h-full w-full place-items-center overflow-hidden", className)}
        style={{
          background: `radial-gradient(120% 90% at 50% 15%, ${entity.accent}26, var(--sa-plate) 68%)`,
        }}
        aria-hidden
      >
        {/* Procedural containment sigil — reads as deliberate, not broken */}
        <svg viewBox="0 0 100 100" className="h-[62%] w-[62%] opacity-70">
          <defs>
            <linearGradient id={`g-${entity.id}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor={entity.accent} stopOpacity="0.9" />
              <stop offset="1" stopColor={entity.accent} stopOpacity="0.15" />
            </linearGradient>
          </defs>
          <circle cx="50" cy="50" r="30" fill="none" stroke={`url(#g-${entity.id})`} strokeWidth="1.5" />
          <circle cx="50" cy="50" r="21" fill="none" stroke={entity.accent} strokeWidth="0.6" opacity="0.5" />
          <path
            d="M50 22 L72 40 L64 70 L36 70 L28 40 Z"
            fill="none"
            stroke={entity.accent}
            strokeWidth="1.2"
            opacity="0.8"
          />
          <path d="M50 4v10M50 86v10M4 50h10M86 50h10" stroke={entity.accent} strokeWidth="1.2" />
        </svg>
        <span className="sa-label absolute bottom-2 text-[var(--sa-text-faint)]">
          Specimen offline
        </span>
      </div>
    );
  }

  return (
    <img
      src={entity.art}
      alt=""
      aria-hidden
      loading="lazy"
      onError={() => setFailed(true)}
      className={cn("sa-specimen h-full w-full object-cover", className)}
    />
  );
}

/* ---------------- Threat: bars + explicit value (never colour alone) ---------------- */

export function ThreatMeter({
  level,
  accent,
  compact,
}: {
  level: number;
  accent: string;
  compact?: boolean;
}) {
  return (
    <span className="inline-flex items-center gap-[3px]" aria-label={`Threat level ${level} of 5`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <span
          key={i}
          className={cn("rounded-[1px]", compact ? "h-[6px] w-[4px]" : "h-[9px] w-[5px]")}
          style={{
            background: i <= level ? accent : "transparent",
            border: i <= level ? "none" : `1px solid var(--sa-line-hi)`,
          }}
        />
      ))}
      <span className="sa-label ml-1 text-[var(--sa-text-faint)]">T{level}</span>
    </span>
  );
}

/* ---------------- Specimen frame: art held under containment ---------------- */

export function EntitySpecimen({
  entity,
  height = 160,
  onClick,
  overlay,
  className,
  rounded = "var(--sa-r-md)",
}: {
  entity: EntityVisual;
  height?: number;
  onClick?: () => void;
  overlay?: ReactNode;
  className?: string;
  rounded?: string;
}) {
  const Tag = onClick ? "button" : "div";
  return (
    <Tag
      onClick={onClick}
      aria-label={onClick ? `Open ${entity.name} case file` : undefined}
      className={cn(
        "sa-grain group relative block w-full overflow-hidden border text-left",
        onClick &&
          "transition-transform duration-[var(--sa-t-base)] hover:-translate-y-0.5 active:translate-y-0",
        className
      )}
      style={{
        height,
        borderRadius: rounded,
        borderColor: `${entity.accent}3d`,
        background: "var(--sa-plate)",
      }}
    >
      <SpecimenImage entity={entity} className="absolute inset-0" />

      {/* legibility scrim */}
      <span
        aria-hidden
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(180deg, rgba(4,6,10,0.08) 0%, rgba(4,6,10,0.52) 50%, rgba(4,6,10,0.95) 100%)",
        }}
      />

      {/* containment brackets */}
      <span aria-hidden className="pointer-events-none absolute inset-[6px]">
        {(
          [
            "left-0 top-0 border-l border-t",
            "right-0 top-0 border-r border-t",
            "left-0 bottom-0 border-l border-b",
            "right-0 bottom-0 border-r border-b",
          ] as const
        ).map((pos) => (
          <span
            key={pos}
            className={cn("absolute h-3.5 w-3.5", pos)}
            style={{ borderColor: `${entity.accent}cc`, borderWidth: 1.5 }}
          />
        ))}
      </span>

      {overlay}
    </Tag>
  );
}

/* ---------------- Roster tile ---------------- */

export function EntityTile({
  entity,
  onClick,
}: {
  entity: EntityVisual;
  onClick?: () => void;
}) {
  return (
    <EntitySpecimen
      entity={entity}
      height={172}
      onClick={onClick}
      overlay={
        <span className="absolute inset-x-0 bottom-0 block p-2.5">
          <span className="sa-label block" style={{ color: entity.accent }}>
            {entity.distortion}
          </span>
          <span className="sa-display mt-1 block text-[13px] leading-[1.15] text-white">
            {entity.name}
          </span>
          <span className="mt-1.5 block">
            <ThreatMeter level={entity.threat} accent={entity.accent} compact />
          </span>
        </span>
      }
    />
  );
}

/* ---------------- Ring (story entry point) ---------------- */

export function EntityRing({
  entity,
  size = 66,
  onOpen,
  showName = true,
}: {
  entity: EntityVisual;
  size?: number;
  onOpen: () => void;
  showName?: boolean;
}) {
  return (
    <button
      onClick={onOpen}
      aria-label={`Open ${entity.name} case file`}
      className="group flex shrink-0 flex-col items-center gap-1.5"
      style={{ width: size + 14 }}
    >
      <span
        className="relative grid place-items-center p-[2px] transition-transform duration-[var(--sa-t-base)] group-hover:scale-[1.05] group-active:scale-95"
        style={{
          width: size,
          height: size,
          borderRadius: "var(--sa-r-md)",
          background: entity.seen
            ? "var(--sa-line)"
            : `conic-gradient(from 210deg, ${entity.accent}, ${entity.accent}1f 48%, ${entity.accent})`,
        }}
      >
        <span
          className="grid h-full w-full place-items-center overflow-hidden"
          style={{
            borderRadius: "calc(var(--sa-r-md) - 2px)",
            background: "var(--sa-bg-0)",
          }}
        >
          <SpecimenImage entity={entity} />
        </span>
        {entity.seen && (
          <span className="sa-label absolute -bottom-0.5 right-0 rounded-sm bg-[var(--sa-bg-0)] px-1 text-[7px] text-[var(--sa-text-faint)]">
            READ
          </span>
        )}
      </span>
      {showName && (
        <span
          className="w-full truncate text-center text-[9px] font-bold leading-tight"
          style={{ color: entity.seen ? "var(--sa-text-dim)" : entity.accent }}
        >
          {entity.name}
        </span>
      )}
    </button>
  );
}

export function EntityRingRow({
  entities,
  onOpen,
  size = 66,
}: {
  entities: EntityVisual[];
  onOpen: (i: number) => void;
  size?: number;
}) {
  return (
    <div className="sa-noscroll -mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
      {entities.map((e, i) => (
        <EntityRing key={e.id} entity={e} size={size} onOpen={() => onOpen(i)} />
      ))}
    </div>
  );
}

/* ---------------- Full-screen case file ---------------- */

interface Page {
  kicker: string;
  title: string;
  body: string;
}

function pagesFor(e: EntityVisual): Page[] {
  return [
    { kicker: "Observed as", title: e.distortion, body: e.observed },
    { kicker: "The tell", title: "How you notice it", body: e.tell },
    { kicker: "The cost", title: `Threat ${e.threat}/5 · logged ${e.encounters}×`, body: e.cost },
    {
      kicker: "Counter instrument",
      title: e.counter,
      body: `Apply ${e.counter} before you commit. You do not fight ${e.name}. You notice it early enough that it stops choosing for you.`,
    },
  ];
}

export function EntityCaseFile({
  entities,
  index,
  onClose,
  onIndexChange,
}: {
  entities: EntityVisual[];
  index: number | null;
  onClose: () => void;
  onIndexChange: (i: number) => void;
}) {
  const [page, setPage] = useState(0);
  const open = index !== null;
  const e = open ? entities[index] : null;

  useEffect(() => setPage(0), [index]);

  const next = useCallback(() => {
    if (!e) return;
    const total = pagesFor(e).length;
    if (page < total - 1) setPage((p) => p + 1);
    else if (index !== null && index < entities.length - 1) onIndexChange(index + 1);
    else onClose();
  }, [e, page, index, entities.length, onIndexChange, onClose]);

  const prev = useCallback(() => {
    if (page > 0) setPage((p) => p - 1);
    else if (index !== null && index > 0) onIndexChange(index - 1);
  }, [page, index, onIndexChange]);

  useEffect(() => {
    if (!open) return;
    const onKey = (ev: KeyboardEvent) => {
      if (ev.key === "Escape") onClose();
      if (ev.key === "ArrowRight") next();
      if (ev.key === "ArrowLeft") prev();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose, next, prev]);

  if (!open || !e) return null;
  const pages = pagesFor(e);
  const p = pages[page];
  const isLast = page === pages.length - 1;

  return (
    <div
      className="fixed inset-0 z-[70] flex justify-center bg-[var(--sa-void)]"
      role="dialog"
      aria-modal="true"
      aria-label={`${e.name} — ${p.title}`}
    >
      <div className="relative flex h-full w-full max-w-[440px] flex-col">
        {/* Specimen fills the upper field */}
        <div className="sa-grain absolute inset-x-0 top-0 h-[60%]">
          <SpecimenImage entity={e} />
          <span
            aria-hidden
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(180deg, rgba(4,6,10,0.78) 0%, rgba(4,6,10,0.08) 26%, rgba(4,6,10,0.88) 76%, var(--sa-void) 100%)",
            }}
          />
        </div>

        {/* Progress segments */}
        <div className="relative z-20 flex gap-1 px-3 pt-3">
          {pages.map((_, i) => (
            <div key={i} className="h-[2.5px] flex-1 overflow-hidden rounded-full bg-white/18">
              <div
                className="h-full origin-left rounded-full"
                style={{
                  background: e.accent,
                  transform: `scaleX(${i <= page ? 1 : 0})`,
                  transition: "transform var(--sa-t-slow) var(--sa-ease)",
                }}
              />
            </div>
          ))}
        </div>

        {/* Header */}
        <div className="relative z-20 flex items-start gap-2 px-4 py-3">
          <div className="min-w-0 flex-1">
            <div className="sa-label" style={{ color: e.accent }}>
              Entity case file
            </div>
            <div className="sa-display mt-1 truncate text-[20px] leading-none text-white">
              {e.name}
            </div>
            <div className="sa-ref mt-1">{e.id.toUpperCase()}</div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close case file"
            className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-white/15 bg-black/50 text-white/80 backdrop-blur hover:text-white active:scale-90"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round">
              <path d="M18 6L6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Tap zones */}
        <button onClick={prev} aria-label="Previous page" className="absolute inset-y-0 left-0 z-10 w-[30%] cursor-default" />
        <button onClick={next} aria-label="Next page" className="absolute inset-y-0 right-0 z-10 w-[70%] cursor-default" />

        {/* Dossier */}
        <div className="relative z-20 mt-auto px-4 pb-[max(env(safe-area-inset-bottom),18px)]">
          {page === 0 && (
            <p
              className="mb-3 text-[17px] font-bold italic leading-snug"
              style={{ color: e.accent }}
            >
              “{e.quote}”
            </p>
          )}
          <div
            key={`${e.id}-${page}`}
            className="sa-slide-in rounded-[var(--sa-r-lg)] border border-[var(--sa-line-hi)] bg-[var(--sa-plate)]/95 p-4 backdrop-blur-xl"
          >
            <div className="flex items-center gap-2">
              <span className="sa-label" style={{ color: e.accent }}>
                {p.kicker}
              </span>
              <span className="sa-rule flex-1" />
            </div>
            <h3 className="sa-display mt-2 text-[18px] leading-tight text-white">{p.title}</h3>
            <p className="mt-2 text-[13.5px] leading-relaxed text-[var(--sa-text)]">{p.body}</p>

            {page === 2 && (
              <div className="mt-3">
                <ThreatMeter level={e.threat} accent={e.accent} />
              </div>
            )}

            <div className="mt-4 flex items-center justify-between gap-3">
              <span className="sa-ref">
                {page + 1} / {pages.length}
              </span>
              <button
                onClick={next}
                className="sa-display min-h-[42px] rounded-[var(--sa-r-sm)] px-5 text-[13px] text-[var(--sa-void)] active:scale-95"
                style={{ background: e.accent }}
              >
                {isLast ? (index < entities.length - 1 ? "Next Entity" : "Close file") : "Continue"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

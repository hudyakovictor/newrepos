import { cn } from "../../utils/cn";
import type { ButtonHTMLAttributes, ReactNode } from "react";

type Variant = "primary" | "signal" | "gold" | "ghost" | "outline" | "danger" | "locked";
type Size = "sm" | "md" | "lg";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  icon?: ReactNode;
  fullWidth?: boolean;
}

const base =
  "relative inline-flex items-center justify-center gap-2 select-none font-[var(--sa-font-display)] font-extrabold " +
  "transition-[transform,filter] duration-[var(--sa-t-fast)] active:translate-y-[2px] " +
  "disabled:opacity-50 disabled:cursor-not-allowed disabled:active:translate-y-0";

const sizes: Record<Size, string> = {
  sm: "min-h-[38px] px-3.5 text-[13px] rounded-[var(--sa-r-sm)]",
  md: "min-h-[46px] px-5 text-[15px] rounded-[var(--sa-r-md)]",
  lg: "min-h-[54px] px-6 text-[16px] rounded-[var(--sa-r-md)]",
};

/* Solid buttons: flat saturated fill + hard bottom edge. No glow at rest. */
const solid = (fill: string, edge: string, text: string) => ({
  className:
    "text-[color:var(--btn-text)] shadow-[0_3px_0_var(--btn-edge)] active:shadow-[0_1px_0_var(--btn-edge)] hover:brightness-[1.08] " +
    "before:pointer-events-none before:absolute before:inset-x-[3px] before:top-[3px] before:h-[34%] before:rounded-[inherit] before:bg-white/12 before:content-['']",
  style: {
    background: fill,
    ["--btn-edge" as string]: edge,
    ["--btn-text" as string]: text,
  } as Record<string, string>,
});

const variants: Record<Variant, { className: string; style?: Record<string, string> }> = {
  signal: solid("var(--sa-signal)", "#0a7048", "var(--sa-signal-ink)"),
  gold: solid("var(--sa-gold)", "#9a6c06", "var(--sa-noise-ink)"),
  danger: solid("var(--sa-danger)", "#8f1f1f", "#ffffff"),
  primary: solid("var(--sa-bg-3)", "#0a0e18", "#ffffff"),
  outline: {
    className:
      "border border-[var(--sa-line-hi)] bg-[var(--sa-bg-2)]/60 text-[var(--sa-text-hi)] hover:border-[var(--sa-signal)] hover:text-[var(--sa-signal)]",
  },
  ghost: {
    className: "bg-transparent text-[var(--sa-text)] hover:bg-white/6 hover:text-[var(--sa-text-hi)]",
  },
  locked: {
    className:
      "bg-[var(--sa-bg-2)] text-[var(--sa-text-dim)] border border-dashed border-[var(--sa-line-hi)] cursor-not-allowed",
  },
};

export function Button({
  variant = "primary",
  size = "md",
  icon,
  fullWidth,
  className,
  children,
  style,
  ...props
}: ButtonProps) {
  const v = variants[variant];
  return (
    <button
      className={cn(base, sizes[size], v.className, fullWidth && "w-full", className)}
      style={{ ...v.style, ...style }}
      {...props}
    >
      {icon && <span className="relative [&_svg]:h-[1.15em] [&_svg]:w-[1.15em]">{icon}</span>}
      <span className="relative">{children}</span>
    </button>
  );
}

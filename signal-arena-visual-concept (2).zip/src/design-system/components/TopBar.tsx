import { cn } from "../../utils/cn";
import { Icon } from "./icons";
import type { ReactNode } from "react";

export function TopBar({
  title,
  onBack,
  right,
  subtitle,
  onProfile,
  onSettings,
  onBell,
  notifCount,
  initials,
}: {
  title?: ReactNode;
  subtitle?: string;
  onBack?: () => void;
  right?: ReactNode;
  onProfile?: () => void;
  onSettings?: () => void;
  onBell?: () => void;
  notifCount?: number;
  initials?: string;
}) {
  return (
    <header className="sticky top-0 z-30 border-b border-[var(--sa-line)] bg-[var(--sa-plate)]/92 backdrop-blur-xl">
      <div className="flex h-15 items-center gap-1.5 px-3 py-2.5">
        {onBack ? (
          <IconBtn onClick={onBack} label="Back">
            <Icon.back />
          </IconBtn>
        ) : (
          <div className="pl-0.5">
            <BrandMark />
          </div>
        )}

        <div className="min-w-0 flex-1">
          {onBack && title && (
            <div className="sa-display truncate text-[16px] leading-tight text-[var(--sa-text-hi)]">
              {title}
            </div>
          )}
          {onBack && subtitle && (
            <div className="sa-label mt-0.5 truncate text-[var(--sa-text-faint)]">{subtitle}</div>
          )}
        </div>

        {right}

        <div className="flex items-center gap-0.5">
          {onBell && (
            <IconBtn onClick={onBell} label="Notifications">
              <Icon.bell />
              {!!notifCount && (
                <span className="absolute right-1 top-1 grid h-[17px] min-w-[17px] place-items-center rounded-full border-2 border-[var(--sa-plate)] bg-[var(--sa-danger)] px-1 text-[9.5px] font-extrabold text-white">
                  {notifCount}
                </span>
              )}
            </IconBtn>
          )}
          {onSettings && (
            <IconBtn onClick={onSettings} label="Settings">
              <Icon.gear />
            </IconBtn>
          )}
          {onProfile && (
            <button
              onClick={onProfile}
              aria-label="Open profile"
              className="ml-1 grid h-11 w-11 shrink-0 place-items-center rounded-full border transition-transform hover:scale-105 active:scale-95"
              style={{
                borderColor: "var(--sa-gold-2)",
                background: "linear-gradient(180deg, var(--sa-bg-3), var(--sa-bg-2))",
              }}
            >
              <span className="sa-display sa-foil text-[13px]">{initials ?? "A4"}</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
}

function IconBtn({
  children,
  onClick,
  label,
}: {
  children: ReactNode;
  onClick: () => void;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      className="relative grid h-11 w-11 shrink-0 place-items-center rounded-[var(--sa-r-sm)] text-[var(--sa-text)] transition-colors hover:bg-white/6 hover:text-[var(--sa-text-hi)] active:scale-95"
    >
      {children}
    </button>
  );
}

/* Brand lockup: gold shield emblem (CSS) + brushed-metal SIGNAL / gold ARENA. */
export function BrandMark({ big }: { big?: boolean }) {
  const s = big ? 40 : 28;
  return (
    <div className="flex items-center gap-2">
      <svg
        width={s}
        height={s}
        viewBox="0 0 48 48"
        aria-hidden
        className="shrink-0 drop-shadow-[0_2px_3px_rgba(0,0,0,0.8)]"
      >
        <defs>
          <linearGradient id="sa-gold-g" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#ffe89a" />
            <stop offset="0.45" stopColor="#ffc328" />
            <stop offset="1" stopColor="#b8810a" />
          </linearGradient>
        </defs>
        {/* crossed candles */}
        <g strokeLinecap="round">
          <line x1="13" y1="36" x2="35" y2="12" stroke="#22c55e" strokeWidth="6" />
          <line x1="35" y1="36" x2="13" y2="12" stroke="#ef4444" strokeWidth="6" />
        </g>
        {/* shield */}
        <path
          d="M24 4l16 5v14c0 10-7 16-16 21C15 39 8 33 8 23V9l16-5z"
          fill="#111826"
          stroke="url(#sa-gold-g)"
          strokeWidth="3.2"
          strokeLinejoin="round"
        />
        <path
          d="M24 4l16 5v14c0 10-7 16-16 21"
          fill="none"
          stroke="#ffe89a"
          strokeWidth="1"
          opacity="0.5"
        />
      </svg>
      <div className="leading-[0.92]">
        <div className={cn("sa-display sa-metal uppercase", big ? "text-[26px]" : "text-[17px]")}>
          Signal
        </div>
        <div
          className={cn(
            "sa-display sa-foil uppercase tracking-[0.3em]",
            big ? "text-[12px]" : "text-[8.5px]"
          )}
        >
          Arena
        </div>
      </div>
    </div>
  );
}

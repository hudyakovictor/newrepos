import { cn } from "../../utils/cn";
import type { ReactNode } from "react";

export function SectionTitle({
  children,
  action,
  kicker,
  className,
}: {
  children: ReactNode;
  action?: ReactNode;
  kicker?: string;
  className?: string;
}) {
  return (
    <div className={cn("mb-3 flex items-end justify-between gap-3", className)}>
      <div className="min-w-0">
        {kicker && (
          <div className="mb-0.5 text-[10px] font-extrabold uppercase tracking-[0.2em] text-[var(--sa-text-faint)]">
            {kicker}
          </div>
        )}
        <h2 className="sa-display text-[21px] leading-tight text-[var(--sa-text-hi)]">{children}</h2>
      </div>
      {action}
    </div>
  );
}

export function Kicker({ children, color }: { children: ReactNode; color?: string }) {
  return (
    <span
      className="text-[10px] font-extrabold uppercase tracking-[0.2em]"
      style={{ color: color ?? "var(--sa-text-faint)" }}
    >
      {children}
    </span>
  );
}

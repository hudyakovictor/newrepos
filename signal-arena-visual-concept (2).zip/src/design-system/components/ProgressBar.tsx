import { cn } from "../../utils/cn";

export function ProgressBar({
  value,
  max = 100,
  color = "var(--sa-signal)",
  label,
  className,
  showValue,
  thick,
}: {
  value: number;
  max?: number;
  color?: string;
  label?: string;
  className?: string;
  showValue?: boolean;
  thick?: boolean;
}) {
  const pct = Math.min(100, Math.round((value / max) * 100));
  return (
    <div className={cn("w-full", className)}>
      {(label || showValue) && (
        <div className="mb-1.5 flex items-center justify-between text-[11px] font-bold uppercase tracking-wide text-[var(--sa-text-dim)]">
          <span>{label}</span>
          {showValue && (
            <span className="sa-mono text-[var(--sa-text-hi)]">
              {value}
              <span className="text-[var(--sa-text-faint)]">/{max}</span>
            </span>
          )}
        </div>
      )}
      <div
        className={cn(
          "w-full overflow-hidden rounded-[var(--sa-r-pill)] border border-[var(--sa-line-soft)] bg-[var(--sa-plate)]",
          "shadow-[inset_0_1px_3px_rgba(0,0,0,0.7)]",
          thick ? "h-4" : "h-3"
        )}
        role="progressbar"
        aria-valuenow={value}
        aria-valuemax={max}
        aria-label={label}
      >
        <div
          className="relative h-full rounded-[var(--sa-r-pill)] transition-[width] duration-[var(--sa-t-slow)]"
          style={{
            width: `${pct}%`,
            background: `linear-gradient(180deg, ${color}, color-mix(in srgb, ${color} 68%, black))`,
          }}
        >
          <span
            aria-hidden
            className="absolute inset-x-1 top-[2px] h-[28%] rounded-full bg-white/25"
          />
        </div>
      </div>
    </div>
  );
}

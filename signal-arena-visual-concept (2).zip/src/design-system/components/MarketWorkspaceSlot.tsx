import { cn } from "../../utils/cn";

/*
 * MarketWorkspaceSlot — RESERVED, NEUTRAL placeholder for the future
 * isolated terminal task. Intentionally contains NO candles, indicators,
 * order book, trade form, entry/stop/target lines, or plausible market data.
 * Only the outer size is adapted at layout level.
 */
export function MarketWorkspaceSlot({
  className,
  height = 200,
  caption = "Market workspace",
}: {
  className?: string;
  height?: number;
  caption?: string;
}) {
  return (
    <div
      className={cn(
        "relative w-full overflow-hidden rounded-[var(--sa-r-lg)] border-2 border-dashed border-[var(--sa-line)]",
        "bg-gradient-to-b from-[var(--sa-bg-2)] to-[var(--sa-bg-1)] shadow-[inset_0_4px_12px_rgba(0,0,0,0.45)]",
        className
      )}
      style={{ height }}
      role="img"
      aria-label="Reserved market workspace — visual placeholder, no live data"
    >
      <div
        aria-hidden
        className="absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)",
          backgroundSize: "14px 14px",
        }}
      />
      <div className="relative flex h-full flex-col items-center justify-center gap-2 px-6 text-center">
        <div className="grid h-14 w-14 place-items-center rounded-full border-2 border-[var(--sa-line)] bg-[var(--sa-bg-3)] text-[var(--sa-text-dim)] shadow-[0_3px_0_rgba(0,0,0,0.35)]">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <circle cx="12" cy="12" r="7" />
            <path d="M12 2v4M12 18v4M2 12h4M18 12h4" />
          </svg>
        </div>
        <p className="sa-display text-[13px] uppercase tracking-[0.16em] text-[var(--sa-text-dim)]">
          {caption}
        </p>
        <p className="max-w-[250px] text-[12px] font-semibold leading-snug text-[var(--sa-text-faint)]">
          Reserved slot. The analytical terminal ships as an isolated task.
        </p>
      </div>
    </div>
  );
}

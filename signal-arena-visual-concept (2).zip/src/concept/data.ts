import raw from "../../content-library/mock-data.json";
import manifest from "../../content-library/included-assets.json";

export const data = raw;
export const player = raw.player;
export const entities = raw.entities;
export const skillCards = raw.skillCards;
export const scenario = raw.scenario;
export const reveal = raw.reveal;

export type Entity = (typeof raw.entities)[number];
export type SkillCard = (typeof raw.skillCards)[number];

/* Provided baseline assets. Runtime uses only what included-assets.json lists. */
const ASSET_BASE = manifest._source;

export const logoUrl = manifest.logo.url;

export const entityArt = (slug: string) => `${ASSET_BASE}${slug}.jpg`;

export const entityById = (id: string): Entity | undefined =>
  entities.find((e) => e.id === id);

export const cardByName = (name: string): SkillCard | undefined =>
  skillCards.find((c) => c.name === name);

export const rarityColor: Record<string, string> = {
  common: "var(--sa-rare-common)",
  rare: "var(--sa-rare-rare)",
  epic: "var(--sa-rare-epic)",
  legendary: "var(--sa-rare-legendary)",
};

/* Evidence quality is never communicated by colour alone. */
export const qualityLabel: Record<string, string> = {
  signal: "Likely signal",
  weak: "Unconfirmed",
  noise: "Likely noise",
};

export const qualityColor: Record<string, string> = {
  signal: "var(--sa-signal)",
  weak: "var(--sa-noise)",
  noise: "var(--sa-danger)",
};

/* Flattened evidence list for screens that don't group by source. */
export const allEvidence = scenario.sourceGroups.flatMap((g) =>
  g.items.map((i) => ({ ...i, group: g.name }))
);

/* Signal vs Noise tally — the core idea, computed from the evidence itself. */
export const signalCount = allEvidence.filter((e) => e.quality === "signal").length;
export const noiseCount = allEvidence.filter((e) => e.quality === "noise").length;
export const unconfirmedCount = allEvidence.filter((e) => e.quality === "weak").length;

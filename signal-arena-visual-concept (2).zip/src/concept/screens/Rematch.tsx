import {
  ScreenShell,
  Card,
  CardBody,
  Plate,
  Button,
  Badge,
  Icon,
  SectionTitle,
} from "../../design-system";
import { useNav } from "../router";
import { scenario, reveal, data, player } from "../data";

export function Rematch() {
  const nav = useNav();
  return (
    <ScreenShell grid>
      <Card accent="var(--sa-gold)" pulse>
        <CardBody className="text-center">
          {/* Gold seal stamp — one-shot animation */}
          <div className="sa-stamp mx-auto grid h-20 w-20 place-items-center rounded-full border-2 border-[var(--sa-gold)] bg-[var(--sa-bg-1)]">
            <span className="sa-display sa-foil text-[11px] leading-[1.1]">
              CASE
              <br />
              SEALED
            </span>
          </div>
          <div className="sa-display mt-3 text-[22px] leading-none text-[var(--sa-text-hi)]">
            {scenario.codename}
          </div>
          <p className="mt-1.5 text-[12.5px] font-semibold text-[var(--sa-text-dim)]">
            Process {reveal.processScore}/{reveal.processMax} · {reveal.processVerdict}
          </p>
          <div className="mt-3.5 flex flex-wrap justify-center gap-1.5">
            <Badge tone="gold" icon={<Icon.star />}>+{scenario.reward.stars}</Badge>
            <Badge tone="neutral" icon={<Icon.coin />}>+{scenario.reward.coins}</Badge>
            <Badge tone="info">Lvl {player.level}</Badge>
          </div>
        </CardBody>
      </Card>

      <div className="mt-5">
        <SectionTitle kicker="Run it again">Rematch</SectionTitle>
        <div className="space-y-3">
          {data.rematch.options.map((o) => (
            <Card
              key={o.id}
              accent={o.accent}
              interactive
              onClick={() => nav.goArena(o.id === "rm-new" ? "home" : "brief")}
            >
              <CardBody className="flex items-center gap-3">
                <div className="min-w-0 flex-1">
                  <div className="sa-display text-[15px] text-[var(--sa-text-hi)]">{o.name}</div>
                  <div className="mt-0.5 text-[12px] font-semibold text-[var(--sa-text-dim)]">
                    {o.desc}
                  </div>
                </div>
                <span className="shrink-0 text-[var(--sa-text-dim)] [&_svg]:h-5 [&_svg]:w-5">
                  <Icon.chevron />
                </span>
              </CardBody>
            </Card>
          ))}
        </div>
      </div>

      <Plate className="mt-5 p-3.5">
        <p className="text-[12.5px] leading-relaxed text-[var(--sa-text-dim)]">
          A rematch is not a retry for a better score. It is a check on whether your reasoning
          survives when the outcome is already known.
        </p>
      </Plate>

      <div className="mt-5">
        <Button variant="outline" size="lg" fullWidth onClick={() => nav.goArena("home")}>
          Return to Arena
        </Button>
      </div>
    </ScreenShell>
  );
}

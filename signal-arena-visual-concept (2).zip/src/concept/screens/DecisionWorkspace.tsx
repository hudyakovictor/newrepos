import { useState } from "react";
import {
  ScreenShell,
  Card,
  CardBody,
  Plate,
  Button,
  Icon,
  MarketWorkspaceSlot,
  Modal,
  EntityRing,
  EntityCaseFile,
  SignalNoiseBar,
  Stamp,
  Rule,
} from "../../design-system";
import { useNav } from "../router";
import {
  scenario,
  skillCards,
  allEvidence,
  qualityLabel,
  qualityColor,
  signalCount,
  noiseCount,
  unconfirmedCount,
} from "../data";
import { entityVisuals, entityIndex } from "../entities";
import { SkillCardTile } from "../components/SkillCardTile";

export function DecisionWorkspace() {
  const nav = useNav();
  const [hypothesis, setHypothesis] = useState<string | null>(null);
  const [action, setAction] = useState<string | null>(null);
  const [invalidation, setInvalidation] = useState("");
  const [confidence, setConfidence] = useState(50);
  const [cards, setCards] = useState<string[]>([]);
  const [confirm, setConfirm] = useState(false);
  const [file, setFile] = useState<number | null>(null);

  const toggle = (id: string) =>
    setCards((p) => (p.includes(id) ? p.filter((x) => x !== id) : p.length >= 3 ? p : [...p, id]));

  const ready = hypothesis !== null && action !== null;

  return (
    <ScreenShell>
      {/* Reserved slot — deliberately empty of market data */}
      <MarketWorkspaceSlot height={168} caption="Market workspace · reserved" />

      {/* Entities in the room */}
      <Plate className="mt-3 flex items-center gap-2 p-2">
        <span className="sa-label shrink-0 pl-1 leading-tight text-[var(--sa-text-faint)]">
          In the
          <br />
          room
        </span>
        <div className="flex flex-1 justify-end gap-1.5">
          {scenario.hiddenEntities.map((id) => {
            const idx = entityIndex(id);
            const e = entityVisuals[idx];
            if (!e) return null;
            return <EntityRing key={id} entity={e} size={46} onOpen={() => setFile(idx)} />;
          })}
        </div>
      </Plate>

      {/* 1 — Evidence */}
      <Step n={1} title="Weigh the evidence" />
      <Plate className="mb-2.5 p-3">
        <SignalNoiseBar signal={signalCount} noise={noiseCount + unconfirmedCount} />
      </Plate>
      <div className="space-y-2">
        {allEvidence.map((e) => (
          <Plate key={e.id} className="flex items-start gap-2.5 p-2.5">
            <span
              className="mt-[3px] h-2.5 w-2.5 shrink-0 rounded-full"
              style={{ background: qualityColor[e.quality] }}
              aria-hidden
            />
            <span className="min-w-0 flex-1">
              <span className="flex items-center justify-between gap-2">
                <span className="sa-label text-[var(--sa-text-dim)]">{e.tag}</span>
                <span className="sa-label shrink-0" style={{ color: qualityColor[e.quality] }}>
                  {qualityLabel[e.quality]}
                </span>
              </span>
              <span className="mt-1 block text-[12.5px] leading-snug text-[var(--sa-text)]">
                {e.text}
              </span>
            </span>
          </Plate>
        ))}
      </div>

      {/* 2 — Tools */}
      <Step n={2} title="Apply instruments" hint={`${cards.length}/3`} />
      <div className="grid grid-cols-2 gap-2.5">
        {skillCards.slice(0, 4).map((c) => (
          <SkillCardTile
            key={c.id}
            card={c}
            selected={cards.includes(c.id)}
            onClick={() => toggle(c.id)}
          />
        ))}
      </div>

      {/* 3 — Hypothesis */}
      <Step n={3} title="State a hypothesis" />
      <div className="space-y-2">
        {scenario.hypotheses.map((h) => {
          const on = hypothesis === h.id;
          return (
            <button
              key={h.id}
              onClick={() => setHypothesis(h.id)}
              aria-pressed={on}
              className="flex min-h-[56px] w-full items-start gap-3 rounded-[var(--sa-r-md)] border p-3 text-left transition-colors duration-[var(--sa-t-fast)]"
              style={{
                borderColor: on ? "var(--sa-signal)" : "var(--sa-line)",
                background: on ? "rgba(46,232,138,0.07)" : "var(--sa-card)",
              }}
            >
              <span
                className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border"
                style={{ borderColor: on ? "var(--sa-signal)" : "var(--sa-line-hi)" }}
              >
                {on && <span className="h-2.5 w-2.5 rounded-full bg-[var(--sa-signal)]" />}
              </span>
              <span className="min-w-0">
                <span className="block text-[14px] font-bold text-[var(--sa-text-hi)]">
                  {h.label}
                </span>
                <span className="mt-0.5 block text-[12px] font-semibold text-[var(--sa-text-dim)]">
                  {h.note}
                </span>
              </span>
            </button>
          );
        })}
      </div>

      {/* 4 — Invalidation */}
      <Step n={4} title="Name your invalidation" />
      <Plate className="p-3">
        <label htmlFor="inval" className="sa-label block text-[var(--sa-text-faint)]">
          What would prove this wrong?
        </label>
        <input
          id="inval"
          value={invalidation}
          onChange={(e) => setInvalidation(e.target.value)}
          placeholder="e.g. reclaim of the range high on rising volume"
          className="mt-2 min-h-[44px] w-full rounded-[var(--sa-r-sm)] border border-[var(--sa-line)] bg-[var(--sa-bg-1)] px-3 text-[13px] font-semibold text-[var(--sa-text-hi)] placeholder:text-[var(--sa-text-faint)]"
        />
        <p className="mt-2 text-[11.5px] font-semibold text-[var(--sa-text-faint)]">
          A thesis without an invalidation point is a wish.
        </p>
      </Plate>

      {/* 5 — Action */}
      <Step n={5} title="Choose an action" />
      <div className="grid grid-cols-3 gap-2">
        {scenario.actions.map((a) => {
          const on = action === a;
          return (
            <button
              key={a}
              onClick={() => setAction(a)}
              aria-pressed={on}
              className="sa-display min-h-[48px] rounded-[var(--sa-r-md)] border text-[13px] transition-colors"
              style={{
                borderColor: on ? "var(--sa-signal)" : "var(--sa-line)",
                background: on ? "rgba(46,232,138,0.1)" : "var(--sa-card)",
                color: on ? "var(--sa-signal)" : "var(--sa-text)",
              }}
            >
              {a}
            </button>
          );
        })}
      </div>

      {/* 6 — Confidence */}
      <Step n={6} title="Calibrate confidence" />
      <Card>
        <CardBody>
          <div className="flex items-baseline justify-between">
            <span className="text-[12.5px] font-semibold text-[var(--sa-text-dim)]">
              How sure are you?
            </span>
            <span className="sa-mono text-[22px] font-bold text-[var(--sa-text-hi)]">
              {confidence}%
            </span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            step={5}
            value={confidence}
            onChange={(e) => setConfidence(Number(e.target.value))}
            aria-label="Confidence"
            className="mt-3 h-6 w-full accent-[var(--sa-signal)]"
          />
          <div className="mt-1 flex justify-between">
            <span className="sa-label text-[var(--sa-text-faint)]">Guessing</span>
            <span className="sa-label text-[var(--sa-text-faint)]">Certain</span>
          </div>
          <p className="mt-2 text-[11.5px] font-semibold text-[var(--sa-text-faint)]">
            Overconfidence is scored against you even when the outcome agrees.
          </p>
        </CardBody>
      </Card>

      {/* Seal */}
      <div className="mt-6 space-y-2">
        <Button
          variant="signal"
          size="lg"
          fullWidth
          disabled={!ready}
          onClick={() => setConfirm(true)}
          icon={<Icon.seal />}
        >
          Seal decision
        </Button>
        {!ready && (
          <p className="text-center text-[12px] font-semibold text-[var(--sa-text-faint)]">
            Pick a hypothesis and an action to seal.
          </p>
        )}
        <Button variant="ghost" size="md" fullWidth onClick={() => nav.goArena("brief")}>
          Back to brief
        </Button>
      </div>

      {/* Decision Seal */}
      <Modal open={confirm} onClose={() => setConfirm(false)} title="Seal this decision?">
        <div className="mb-3 flex justify-center">
          <Stamp tone="gold" size="lg" animate>
            Sealed
          </Stamp>
        </div>
        <p className="text-[13px] leading-relaxed text-[var(--sa-text)]">
          Sealing locks your reasoning before the outcome is revealed. That is the whole exercise —
          commit first, then face what actually happened.
        </p>
        <Rule label="Your record" className="mt-4" />
        <Plate className="mt-2 p-3">
          <Row label="Hypothesis" value={scenario.hypotheses.find((h) => h.id === hypothesis)?.label ?? "—"} />
          <Row label="Action" value={action ?? "—"} />
          <Row label="Invalidation" value={invalidation || "Not stated"} />
          <Row label="Confidence" value={`${confidence}%`} />
          <Row label="Instruments" value={`${cards.length}`} />
        </Plate>
        {!invalidation && (
          <div className="mt-3 flex items-start gap-2 rounded-[var(--sa-r-sm)] border border-[var(--sa-noise)]/40 bg-[var(--sa-noise)]/8 p-2.5">
            <span className="shrink-0 text-[var(--sa-noise)] [&_svg]:h-4 [&_svg]:w-4">
              <Icon.flame />
            </span>
            <p className="text-[12px] font-semibold text-[var(--sa-noise)]">
              No invalidation stated. You will lose process points for this.
            </p>
          </div>
        )}
        <div className="mt-4 flex gap-2">
          <Button variant="ghost" fullWidth onClick={() => setConfirm(false)}>
            Review
          </Button>
          <Button
            variant="signal"
            fullWidth
            onClick={() => {
              setConfirm(false);
              nav.goArena("reveal");
            }}
          >
            Seal &amp; reveal
          </Button>
        </div>
      </Modal>

      <EntityCaseFile
        entities={entityVisuals}
        index={file}
        onClose={() => setFile(null)}
        onIndexChange={setFile}
      />
    </ScreenShell>
  );
}

function Step({ n, title, hint }: { n: number; title: string; hint?: string }) {
  return (
    <div className="mb-2.5 mt-6 flex items-center gap-2">
      <span className="sa-mono grid h-6 w-6 shrink-0 place-items-center rounded-[var(--sa-r-sm)] border border-[var(--sa-line-hi)] bg-[var(--sa-bg-2)] text-[11px] font-bold text-[var(--sa-signal)]">
        {n}
      </span>
      <h3 className="sa-display flex-1 text-[15px] text-[var(--sa-text-hi)]">{title}</h3>
      {hint && <span className="sa-mono text-[11px] font-bold text-[var(--sa-text-dim)]">{hint}</span>}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 py-1">
      <span className="sa-label shrink-0 text-[var(--sa-text-faint)]">{label}</span>
      <span className="text-right text-[12.5px] font-bold text-[var(--sa-text-hi)]">{value}</span>
    </div>
  );
}

import { useState } from "react";
import {
  ScreenShell,
  Card,
  CardBody,
  Plate,
  SectionTitle,
  Button,
  ProgressBar,
  Badge,
  Icon,
  EntityRingRow,
  EntityCaseFile,
  Stamp,
  EvidenceTag,
  Rule,
} from "../../design-system";
import { useNav } from "../router";
import { player, scenario, signalCount, noiseCount, unconfirmedCount } from "../data";
import { entityVisuals } from "../entities";

export function Hub() {
  const nav = useNav();
  const [file, setFile] = useState<number | null>(null);

  return (
    <ScreenShell grid>
      {/* ---- Analyst record ---- */}
      <Card accent="var(--sa-gold)">
        <CardBody className="pb-3.5">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <Rule label="Analyst record" />
              <div className="sa-display mt-2 text-[25px] leading-none text-[var(--sa-text-hi)]">
                {player.handle}
              </div>
              <div className="mt-1.5 text-[12px] font-semibold text-[var(--sa-text-dim)]">
                Lvl {player.level} · {player.levelTitle}
              </div>
            </div>
            <Stamp tone="signal" size="sm">
              {player.streakDays}d streak
            </Stamp>
          </div>
          <div className="mt-4">
            <ProgressBar
              value={player.xp}
              max={player.xpToNext}
              color="var(--sa-gold)"
              label="XP"
              showValue
            />
          </div>
        </CardBody>
        <div className="grid grid-cols-3 border-t border-[var(--sa-line-soft)] bg-black/35">
          {[
            { v: player.processScore, l: "Process", c: "var(--sa-signal)" },
            { v: player.rank, l: "Rank", c: "var(--sa-hub)" },
            { v: `${player.energy}/${player.energyMax}`, l: "Energy", c: "var(--sa-noise)" },
          ].map((s, i) => (
            <div
              key={s.l}
              className={cnCell(i)}
            >
              <div className="sa-display text-[19px] leading-none" style={{ color: s.c }}>
                {s.v}
              </div>
              <div className="sa-label mt-1.5 text-[var(--sa-text-faint)]">{s.l}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* ---- Entities: tap to open the file ---- */}
      <div className="mt-6">
        <SectionTitle
          kicker="Known distortions · tap to open"
          action={
            <Button size="sm" variant="ghost" onClick={() => nav.goAcademyCollection(true)}>
              Vault
            </Button>
          }
        >
          Entities
        </SectionTitle>
        <EntityRingRow entities={entityVisuals} onOpen={setFile} />
      </div>

      {/* ---- Open case ---- */}
      <div className="mt-5">
        <SectionTitle kicker="Open case" action={<Stamp tone="danger" size="sm">9h left</Stamp>}>
          Daily Case
        </SectionTitle>
        <Card accent="var(--sa-signal)" interactive onClick={() => nav.goArena("brief")}>
          <CardBody>
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="sa-display text-[21px] leading-none text-[var(--sa-text-hi)]">
                  {scenario.codename}
                </div>
                <div className="mt-1.5 text-[12px] font-semibold text-[var(--sa-text-dim)]">
                  {scenario.asset}
                </div>
              </div>
              <span className="sa-ref shrink-0">LVL {scenario.level}</span>
            </div>

            {/* Evidence tally — signal vs noise made literal */}
            <div className="mt-3.5 flex flex-wrap gap-1.5">
              <EvidenceTag tone="var(--sa-signal)">{signalCount} signal</EvidenceTag>
              <EvidenceTag tone="var(--sa-noise)">{unconfirmedCount} unconfirmed</EvidenceTag>
              <EvidenceTag tone="var(--sa-danger)">{noiseCount} noise</EvidenceTag>
            </div>

            <Rule className="my-3.5" />

            <div className="flex items-center justify-between gap-2">
              <div className="flex flex-wrap gap-1.5">
                <Badge tone="signal" icon={<Icon.star />}>+{scenario.reward.stars}</Badge>
                <Badge tone="neutral" icon={<Icon.bolt />}>1</Badge>
              </div>
              <span className="sa-label text-[var(--sa-text-faint)]">
                +{scenario.reward.process} process
              </span>
            </div>

            <Button variant="signal" size="lg" fullWidth className="mt-3.5">
              Open case file
            </Button>
          </CardBody>
        </Card>
      </div>

      {/* ---- Academy ---- */}
      <div className="mt-6">
        <SectionTitle
          kicker="Training"
          action={
            <Button size="sm" variant="ghost" onClick={() => nav.goSection("academy")}>
              Open
            </Button>
          }
        >
          Continue lesson
        </SectionTitle>
        <Card interactive accent="var(--sa-academy)" onClick={() => nav.goSection("academy")}>
          <CardBody>
            <div className="sa-label text-[var(--sa-academy)]">{player.currentLesson.track}</div>
            <div className="sa-display mt-1.5 text-[16px] text-[var(--sa-text-hi)]">
              {player.currentLesson.unit}
            </div>
            <div className="mt-3">
              <ProgressBar
                value={player.currentLesson.progress}
                color="var(--sa-academy)"
                label="Unit"
                showValue
              />
            </div>
          </CardBody>
        </Card>
      </div>

      {/* ---- Personal insight ---- */}
      <div className="mt-6">
        <SectionTitle kicker="Pattern across cases">Personal insight</SectionTitle>
        <Plate className="p-4">
          <Rule label="Repeated error" />
          <p className="mt-2.5 text-[13.5px] leading-relaxed text-[var(--sa-text)]">
            Twice this week you treated a single unconfirmed candle as confirmation.
          </p>
          <button
            onClick={() => setFile(4)}
            className="sa-display mt-3 inline-flex min-h-[40px] items-center gap-1.5 text-[13px] text-[var(--sa-signal)]"
          >
            Review Wick Mimic
            <span className="[&_svg]:h-4 [&_svg]:w-4">
              <Icon.chevron />
            </span>
          </button>
        </Plate>
      </div>

      {/* ---- Quick tiles ---- */}
      <div className="mt-6 grid grid-cols-2 gap-3">
        <QuickTile
          icon={<Icon.shop />}
          label="Shop"
          sub="Cosmetic only"
          c="var(--sa-shop)"
          onClick={() => nav.goSection("shop")}
        />
        <QuickTile
          icon={<Icon.tournament />}
          label="Tournaments"
          sub="Staged"
          c="var(--sa-cups)"
          onClick={() => nav.goSection("tournament")}
        />
      </div>

      <EntityCaseFile
        entities={entityVisuals}
        index={file}
        onClose={() => setFile(null)}
        onIndexChange={setFile}
      />
    </ScreenShell>
  );
}

function cnCell(i: number) {
  return i
    ? "border-l border-[var(--sa-line-soft)] py-3 text-center"
    : "py-3 text-center";
}

function QuickTile({
  icon,
  label,
  sub,
  c,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  sub: string;
  c: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex min-h-[98px] flex-col gap-2.5 rounded-[var(--sa-r-lg)] border border-[var(--sa-line)] bg-gradient-to-b from-[var(--sa-card-hi)] to-[var(--sa-card)] p-4 text-left shadow-[var(--sa-shadow-pop)] transition-[transform,border-color] duration-[var(--sa-t-base)] hover:-translate-y-0.5 hover:border-[var(--sa-line-hi)] active:translate-y-0"
    >
      <span
        className="grid h-9 w-9 place-items-center rounded-[var(--sa-r-sm)] border border-[var(--sa-line-hi)] bg-[var(--sa-bg-2)] [&_svg]:h-[18px] [&_svg]:w-[18px]"
        style={{ color: c }}
      >
        {icon}
      </span>
      <div>
        <div className="sa-display text-[15px] text-[var(--sa-text-hi)]">{label}</div>
        <div className="sa-label mt-1 text-[var(--sa-text-faint)]">{sub}</div>
      </div>
    </button>
  );
}

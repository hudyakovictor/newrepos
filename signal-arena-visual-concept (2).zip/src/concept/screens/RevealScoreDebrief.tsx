import { useState } from "react";
import {
  ScreenShell,
  Card,
  CardBody,
  Plate,
  Button,
  Icon,
  ProgressBar,
  SectionTitle,
  EntitySpecimen,
  EntityCaseFile,
  ThreatMeter,
  Stamp,
  Rule,
} from "../../design-system";
import { useNav } from "../router";
import { reveal } from "../data";
import { entityVisuals, entityIndex } from "../entities";

export function RevealScoreDebrief() {
  const nav = useNav();
  const idx = entityIndex(reveal.revealedEntity);
  const ent = entityVisuals[idx];
  const [file, setFile] = useState<number | null>(null);

  return (
    <ScreenShell>
      {/* ---- Historical reveal ---- */}
      <Card accent={reveal.decisionWasRight ? "var(--sa-signal)" : "var(--sa-danger)"} pulse>
        <CardBody>
          <div className="flex items-start justify-between gap-3">
            <Rule label="Historical reveal" className="flex-1" />
            <Stamp
              tone={reveal.decisionWasRight ? "signal" : "danger"}
              size="sm"
              animate
            >
              {reveal.decisionWasRight ? "Outcome matched" : "Outcome missed"}
            </Stamp>
          </div>
          <p className="mt-3 text-[15px] leading-relaxed text-[var(--sa-text-hi)]">
            {reveal.outcome}
          </p>
        </CardBody>
      </Card>

      {/* ---- The separation that matters ---- */}
      <Plate className="mt-3 p-4" accent="var(--sa-noise)">
        <Rule label="The hard truth" />
        <p className="mt-2.5 text-[13.5px] leading-relaxed text-[var(--sa-text)]">{reveal.note}</p>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <div className="rounded-[var(--sa-r-sm)] border border-[var(--sa-line-hi)] bg-[var(--sa-bg-2)] p-2.5 text-center">
            <div className="sa-label text-[var(--sa-text-faint)]">Outcome</div>
            <div
              className="sa-display mt-1 text-[13px]"
              style={{ color: reveal.decisionWasRight ? "var(--sa-signal)" : "var(--sa-danger)" }}
            >
              {reveal.decisionWasRight ? "Favourable" : "Against"}
            </div>
          </div>
          <div className="rounded-[var(--sa-r-sm)] border border-[var(--sa-line-hi)] bg-[var(--sa-bg-2)] p-2.5 text-center">
            <div className="sa-label text-[var(--sa-text-faint)]">Process</div>
            <div className="sa-display mt-1 text-[13px] capitalize text-[var(--sa-signal)]">
              {reveal.processVerdict}
            </div>
          </div>
        </div>
        <p className="mt-2.5 text-[11.5px] font-semibold leading-snug text-[var(--sa-text-faint)]">
          These two are scored separately. Only the right-hand column is yours.
        </p>
      </Plate>

      {/* ---- Score ---- */}
      <div className="mt-6">
        <SectionTitle
          kicker="Scoring · process only"
          action={
            <span className="sa-display text-[26px] leading-none text-[var(--sa-signal)]">
              {reveal.processScore}
              <span className="text-[15px] text-[var(--sa-text-faint)]">/{reveal.processMax}</span>
            </span>
          }
        >
          Process score
        </SectionTitle>
        <Card>
          <CardBody className="space-y-3.5">
            {reveal.scoreBreakdown.map((b) => {
              const full = b.points === b.max;
              const zero = b.points === 0;
              const c = zero
                ? "var(--sa-danger)"
                : full
                ? "var(--sa-signal)"
                : "var(--sa-noise)";
              return (
                <div key={b.id}>
                  <div className="mb-1.5 flex items-start justify-between gap-2">
                    <span className="text-[12.5px] font-semibold leading-snug text-[var(--sa-text)]">
                      {b.label}
                    </span>
                    <span className="sa-mono shrink-0 text-[12px] font-bold" style={{ color: c }}>
                      {b.points}/{b.max}
                    </span>
                  </div>
                  <ProgressBar value={b.points} max={b.max} color={c} />
                </div>
              );
            })}
          </CardBody>
        </Card>
        <p className="mt-2 text-[11.5px] font-semibold text-[var(--sa-text-faint)]">
          You lost 2 points for not naming the Entity. Noticing it is the skill.
        </p>
      </div>

      {/* ---- Debrief: specimen identified ---- */}
      <div className="mt-6">
        <SectionTitle kicker="Debrief">Identified specimen</SectionTitle>
        {ent && (
          <EntitySpecimen
            entity={ent}
            height={215}
            rounded="var(--sa-r-lg)"
            className="sa-pop"
            onClick={() => setFile(idx)}
            overlay={
              <>
                <span className="absolute right-3 top-3">
                  <Stamp tone="danger" size="sm" animate>
                    Present
                  </Stamp>
                </span>
                <span className="absolute inset-x-0 bottom-0 block p-4">
                  <span className="sa-label block" style={{ color: ent.accent }}>
                    {ent.distortion}
                  </span>
                  <span className="sa-display mt-1 block text-[21px] leading-none text-white">
                    {ent.name}
                  </span>
                  <span className="mt-2 block text-[12.5px] font-semibold italic leading-snug text-white/75">
                    “{ent.quote}”
                  </span>
                  <span className="mt-2.5 flex items-center justify-between gap-2">
                    <ThreatMeter level={ent.threat} accent={ent.accent} compact />
                    <span
                      className="sa-display inline-flex items-center gap-1 text-[12px]"
                      style={{ color: ent.accent }}
                    >
                      Open file
                      <span className="[&_svg]:h-3.5 [&_svg]:w-3.5">
                        <Icon.chevron />
                      </span>
                    </span>
                  </span>
                </span>
              </>
            }
          />
        )}
        {ent && (
          <Plate className="mt-2.5 flex items-center gap-3 p-3.5">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-[var(--sa-r-sm)] border border-[var(--sa-signal)]/40 bg-[var(--sa-signal)]/10 text-[var(--sa-signal)] [&_svg]:h-[18px] [&_svg]:w-[18px]">
              <Icon.scale />
            </span>
            <span className="min-w-0">
              <span className="sa-label block text-[var(--sa-text-faint)]">Counter instrument</span>
              <span className="sa-display mt-0.5 block text-[14px] text-[var(--sa-signal)]">
                {ent.counter}
              </span>
            </span>
          </Plate>
        )}
      </div>

      {/* ---- Personal insight ---- */}
      <div className="mt-6">
        <SectionTitle kicker="Pattern across cases">Personal insight</SectionTitle>
        <Plate className="p-4" accent="var(--sa-cups)">
          <p className="text-[13.5px] leading-relaxed text-[var(--sa-text)]">{reveal.insight}</p>
        </Plate>
      </div>

      <div className="mt-7 space-y-2">
        <Button variant="signal" size="lg" fullWidth onClick={() => nav.goArena("rematch")}>
          Continue to rematch
        </Button>
        <Button variant="ghost" size="md" fullWidth onClick={() => nav.goArena("home")}>
          Return to Arena
        </Button>
      </div>

      <EntityCaseFile
        entities={entityVisuals}
        index={file}
        onClose={() => setFile(null)}
        onIndexChange={setFile}
      />
    </ScreenShell>
  );
}

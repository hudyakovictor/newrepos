import {
  ScreenShell,
  Card,
  CardBody,
  Plate,
  Button,
  Badge,
  Icon,
  SectionTitle,
} from "../../design-system";
import { data, rarityColor } from "../data";

export function Shop() {
  const shop = data.shop;
  return (
    <ScreenShell grid>
      <Card accent="var(--sa-gold)">
        <CardBody>
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <Badge tone="gold">Season pass</Badge>
              <div className="sa-display mt-2 text-[22px] leading-none text-[var(--sa-text-hi)]">
                {shop.featured.name}
              </div>
              <p className="mt-1.5 text-[12.5px] font-semibold leading-snug text-[var(--sa-text-dim)]">
                {shop.featured.desc}
              </p>
            </div>
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-[var(--sa-r-md)] border border-[var(--sa-gold)]/40 bg-[var(--sa-bg-2)] text-[var(--sa-gold)] [&_svg]:h-6 [&_svg]:w-6">
              <Icon.seal />
            </span>
          </div>
          <div className="mt-4 flex items-center gap-2">
            <Button variant="gold" size="md" className="flex-1" icon={<Icon.star />}>
              {shop.featured.price}
            </Button>
            <Button variant="outline" size="md">
              Preview
            </Button>
          </div>
        </CardBody>
      </Card>

      {shop.sections.map((sec) => (
        <div key={sec.id} className="mt-5">
          <SectionTitle kicker="Cosmetic only">{sec.name}</SectionTitle>
          <div className="grid grid-cols-2 gap-3">
            {sec.items.map((it) => {
              const rc = rarityColor[it.rarity] ?? "var(--sa-line)";
              return (
                <Card key={it.id} interactive>
                  <div
                    className="flex h-[70px] items-center justify-center border-b"
                    style={{
                      background: `linear-gradient(165deg, ${rc}1f, var(--sa-plate))`,
                      borderColor: `${rc}2e`,
                    }}
                  >
                    <span className="[&_svg]:h-6 [&_svg]:w-6" style={{ color: rc }}>
                      <Icon.layers />
                    </span>
                  </div>
                  <CardBody className="p-3">
                    <div className="sa-label" style={{ color: rc }}>
                      {it.rarity}
                    </div>
                    <div className="mt-0.5 text-[13px] font-bold text-[var(--sa-text-hi)]">
                      {it.name}
                    </div>
                    <div className="mt-2 flex items-center gap-1">
                      <span
                        className="[&_svg]:h-3.5 [&_svg]:w-3.5"
                        style={{
                          color:
                            it.currency === "stars" ? "var(--sa-gold)" : "var(--sa-hub)",
                        }}
                      >
                        {it.currency === "stars" ? <Icon.star /> : <Icon.coin />}
                      </span>
                      <span className="sa-mono text-[13px] font-bold text-[var(--sa-text-hi)]">
                        {it.price}
                      </span>
                    </div>
                  </CardBody>
                </Card>
              );
            })}
          </div>
        </div>
      ))}

      <div className="mt-6">
        <SectionTitle kicker="Fairness">House rules</SectionTitle>
        <Plate className="p-3.5">
          <ul className="space-y-2">
            {shop.rules.map((r) => (
              <li key={r} className="flex items-start gap-2">
                <span className="mt-0.5 shrink-0 text-[var(--sa-signal)] [&_svg]:h-4 [&_svg]:w-4">
                  <Icon.check />
                </span>
                <span className="text-[12.5px] font-semibold leading-snug text-[var(--sa-text-dim)]">
                  {r}
                </span>
              </li>
            ))}
          </ul>
        </Plate>
      </div>
    </ScreenShell>
  );
}

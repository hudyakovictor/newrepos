import { useState } from "react";
import {
  ScreenShell,
  Card,
  CardBody,
  Plate,
  Button,
  Badge,
  Icon,
  SectionTitle,
  EntityRing,
  EntityCaseFile,
  Stamp,
  EvidenceTag,
  Rule,
  SignalNoiseBar,
} from "../../design-system";
import { useNav } from "../router";
import {
  scenario,
  qualityLabel,
  qualityColor,
  signalCount,
  noiseCount,
  unconfirmedCount,
} from "../data";
import { entityVisuals, entityIndex } from "../entities";

export function ScenarioBrief() {
  const nav = useNav();
  const [file, setFile] = useState<number | null>(null);

  return (
    <ScreenShell>
      {/* Case header */}
      <Card accent="var(--sa-signal)">
        <CardBody>
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <Rule label={`Case ${scenario.id}`} />
              <div className="sa-display mt-2 text-[26px] leading-none text-[var(--sa-text-hi)]">
                {scenario.codename}
              </div>
              <div className="mt-1.5 text-[12.5px] font-semibold text-[var(--sa-text-dim)]">
                {scenario.asset}
              </div>
              <div className="sa-ref mt-1">{scenario.era}</div>
            </div>
            <Stamp tone="muted" size="sm">
              {scenario.difficulty}
            </Stamp>
          </div>

          <p className="mt-3.5 text-[14px] leading-relaxed text-[var(--sa-text)]">
            {scenario.brief}
          </p>

          <Plate className="mt-4 p-3">
            <SignalNoiseBar signal={signalCount} noise={noiseCount + unconfirmedCount} />
            <p className="mt-2 text-[11.5px] font-semibold text-[var(--sa-text-faint)]">
              {unconfirmedCount} of those are unconfirmed, not yet noise. Grade them yourself.
            </p>
          </Plate>

          <div className="mt-3 flex flex-wrap gap-1.5">
            <Badge tone="signal" icon={<Icon.star />}>+{scenario.reward.stars}</Badge>
            <Badge tone="neutral" icon={<Icon.coin />}>+{scenario.reward.coins}</Badge>
            <Badge tone="info">+{scenario.reward.process} process</Badge>
          </div>
        </CardBody>
      </Card>

      {/* Source groups */}
      <div className="mt-6">
        <SectionTitle kicker="Public projection · pre-seal">Source groups</SectionTitle>
        <div className="space-y-4">
          {scenario.sourceGroups.map((g) => (
            <div key={g.id}>
              <Rule label={g.name} className="mb-2" />
              <div className="space-y-2">
                {g.items.map((e) => (
                  <Plate key={e.id} className="p-3" accent={qualityColor[e.quality]}>
                    <div className="flex items-start justify-between gap-2">
                      <EvidenceTag tone={qualityColor[e.quality]}>{e.tag}</EvidenceTag>
                      <span
                        className="sa-label shrink-0 pt-1"
                        style={{ color: qualityColor[e.quality] }}
                      >
                        {qualityLabel[e.quality]}
                      </span>
                    </div>
                    <p className="mt-2 text-[13px] leading-snug text-[var(--sa-text)]">{e.text}</p>
                  </Plate>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Hidden Entities — withheld until reveal */}
      <div className="mt-6">
        <SectionTitle kicker="May be acting on you">Suspected Entities</SectionTitle>
        <div className="flex gap-2">
          {scenario.hiddenEntities.map((id) => {
            const idx = entityIndex(id);
            const e = entityVisuals[idx];
            if (!e) return null;
            return <EntityRing key={id} entity={e} size={76} onOpen={() => setFile(idx)} />;
          })}
        </div>
        <p className="mt-2.5 text-[12px] font-semibold text-[var(--sa-text-faint)]">
          Which one is actually present stays withheld until the reveal.
        </p>
      </div>

      <div className="mt-7 space-y-2">
        <Button
          variant="signal"
          size="lg"
          fullWidth
          onClick={() => nav.goArena("workspace")}
          icon={<Icon.eye />}
        >
          Open Decision Workspace
        </Button>
        <Button variant="ghost" size="md" fullWidth onClick={() => nav.goArena("home")}>
          Back to modes
        </Button>
      </div>

      <EntityCaseFile
        entities={entityVisuals}
        index={file}
        onClose={() => setFile(null)}
        onIndexChange={setFile}
      />
    </ScreenShell>
  );
}

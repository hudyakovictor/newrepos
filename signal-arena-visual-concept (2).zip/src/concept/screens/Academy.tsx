import { useState } from "react";
import {
  ScreenShell,
  Card,
  CardBody,
  SectionTitle,
  Button,
  ProgressBar,
  Badge,
  Icon,
  Sheet,
} from "../../design-system";
import { data, player, skillCards, entities } from "../data";
import { SkillCardTile } from "../components/SkillCardTile";
import { AcademyCollection } from "./AcademyCollection";
import type { SkillCardData } from "../components/SkillCardTile";

export function Academy({
  collectionOpen,
  setCollectionOpen,
}: {
  collectionOpen: boolean;
  setCollectionOpen: (v: boolean) => void;
}) {
  const [detail, setDetail] = useState<SkillCardData | null>(null);

  if (collectionOpen) return <AcademyCollection onBack={() => setCollectionOpen(false)} />;

  return (
    <ScreenShell grid>
      <Card accent="var(--sa-academy)">
        <CardBody>
          <div className="sa-label text-[var(--sa-academy)]">Now studying</div>
          <div className="sa-display mt-1 text-[19px] leading-tight text-[var(--sa-text-hi)]">
            {player.currentLesson.track}
          </div>
          <div className="mt-0.5 text-[13px] font-semibold text-[var(--sa-text-dim)]">
            {player.currentLesson.unit}
          </div>
          <div className="mt-3">
            <ProgressBar
              value={player.currentLesson.progress}
              color="var(--sa-academy)"
              label="Unit progress"
              showValue
            />
          </div>
          <Button variant="signal" size="lg" fullWidth className="mt-3.5">
            Resume unit
          </Button>
        </CardBody>
      </Card>

      <div className="mt-5">
        <SectionTitle kicker="Curriculum">Tracks</SectionTitle>
        <div className="space-y-3">
          {data.academyTracks.map((t) => (
            <Card key={t.id} accent={t.accent} interactive>
              <CardBody>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="sa-display text-[15px] text-[var(--sa-text-hi)]">{t.name}</div>
                    <p className="mt-1 text-[12px] font-semibold text-[var(--sa-text-dim)]">
                      {t.desc}
                    </p>
                  </div>
                  <Badge tone={t.done === 0 ? "locked" : "neutral"}>
                    {t.done}/{t.units}
                  </Badge>
                </div>
                <div className="mt-3">
                  <ProgressBar value={t.done} max={t.units} color={t.accent} />
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      </div>

      {/* Nested Vault */}
      <div className="mt-5">
        <SectionTitle kicker="Reference catalog">Collection · Vault</SectionTitle>
        <Card interactive accent="var(--sa-gold)" onClick={() => setCollectionOpen(true)}>
          <CardBody className="flex items-center gap-3">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-[var(--sa-r-sm)] border border-[var(--sa-line-hi)] bg-[var(--sa-bg-2)] text-[var(--sa-gold)] [&_svg]:h-5 [&_svg]:w-5">
              <Icon.layers />
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-[13.5px] font-bold text-[var(--sa-text-hi)]">
                {skillCards.length} Skill Cards · {entities.length} Entities
              </div>
              <div className="text-[12px] font-semibold text-[var(--sa-text-dim)]">
                Analytical instruments and the distortions they counter.
              </div>
            </div>
            <span className="shrink-0 text-[var(--sa-text-dim)] [&_svg]:h-5 [&_svg]:w-5">
              <Icon.chevron />
            </span>
          </CardBody>
        </Card>
      </div>

      <div className="mt-5">
        <SectionTitle kicker="From the Vault">Featured instruments</SectionTitle>
        <div className="grid grid-cols-2 gap-3">
          {skillCards.slice(0, 2).map((c) => (
            <SkillCardTile key={c.id} card={c} onClick={() => setDetail(c)} />
          ))}
        </div>
      </div>

      <Sheet open={!!detail} onClose={() => setDetail(null)} title={detail?.name}>
        {detail && (
          <div>
            <div className="mb-3 flex items-center gap-2">
              <Badge tone="info">{detail.rarity}</Badge>
              <Badge tone="neutral">{detail.type}</Badge>
            </div>
            <p className="text-[14px] leading-relaxed text-[var(--sa-text)]">{detail.body}</p>
          </div>
        )}
      </Sheet>
    </ScreenShell>
  );
}

import { useState } from "react";
import {
  Sheet,
  Card,
  CardBody,
  Plate,
  Badge,
  Button,
  Icon,
  ProgressBar,
  EntityRing,
  EntityCaseFile,
} from "../../design-system";
import { player, skillCards } from "../data";
import { entityVisuals } from "../entities";

export function Profile({
  open,
  onClose,
  onOpenVault,
}: {
  open: boolean;
  onClose: () => void;
  onOpenVault: () => void;
}) {
  const [file, setFile] = useState<number | null>(null);

  return (
    <>
      <Sheet open={open} onClose={onClose} title="Profile" side="right">
        <Card accent="var(--sa-gold)">
          <CardBody>
            <div className="flex items-center gap-3">
              <span
                className="grid h-14 w-14 shrink-0 place-items-center rounded-[var(--sa-r-md)] border"
                style={{
                  borderColor: "var(--sa-gold-2)",
                  background: "linear-gradient(180deg, var(--sa-bg-3), var(--sa-bg-2))",
                }}
              >
                <span className="sa-display sa-foil text-[18px]">{player.initials}</span>
              </span>
              <div className="min-w-0">
                <div className="sa-display text-[19px] leading-none text-[var(--sa-text-hi)]">
                  {player.handle}
                </div>
                <div className="mt-1 text-[12px] font-semibold text-[var(--sa-text-dim)]">
                  Lvl {player.level} · {player.levelTitle}
                </div>
                <div className="mt-1.5">
                  <Badge tone="signal">Process {player.processScore}</Badge>
                </div>
              </div>
            </div>
            <div className="mt-3.5">
              <ProgressBar
                value={player.xp}
                max={player.xpToNext}
                label="XP"
                color="var(--sa-gold)"
                showValue
              />
            </div>
          </CardBody>
        </Card>

        <div className="mt-3 grid grid-cols-3 gap-2">
          {[
            { i: <Icon.star />, v: player.stars, l: "Stars", c: "var(--sa-gold)" },
            { i: <Icon.coin />, v: player.coins, l: "Coins", c: "var(--sa-hub)" },
            { i: <Icon.flame />, v: `${player.streakDays}d`, l: "Streak", c: "var(--sa-signal)" },
          ].map((s) => (
            <Plate key={s.l} className="p-3 text-center">
              <span className="[&_svg]:mx-auto [&_svg]:h-[18px] [&_svg]:w-[18px]" style={{ color: s.c }}>
                {s.i}
              </span>
              <div className="sa-display mt-1.5 text-[16px] leading-none text-[var(--sa-text-hi)]">
                {s.v}
              </div>
              <div className="sa-label mt-1 text-[var(--sa-text-faint)]">{s.l}</div>
            </Plate>
          ))}
        </div>

        <div className="mt-5">
          <div className="mb-2 flex items-center justify-between gap-2">
            <span className="sa-label text-[var(--sa-text-faint)]">Loadout</span>
            <Button size="sm" variant="ghost" onClick={onOpenVault}>
              Vault →
            </Button>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {skillCards.slice(0, 3).map((c) => (
              <Plate key={c.id} className="p-2.5 text-center">
                <div className="sa-display text-[12px] leading-tight text-[var(--sa-text-hi)]">
                  {c.name}
                </div>
                <div className="sa-label mt-1 text-[var(--sa-text-faint)]">{c.type}</div>
              </Plate>
            ))}
          </div>
        </div>

        <div className="mt-5">
          <span className="sa-label text-[var(--sa-text-faint)]">Entities encountered</span>
          <div className="mt-2 flex flex-wrap gap-2">
            {entityVisuals.map((e, i) => (
              <EntityRing key={e.id} entity={e} size={58} onOpen={() => setFile(i)} />
            ))}
          </div>
        </div>

        <Plate className="mt-5 p-3.5">
          <div className="sa-label text-[var(--sa-text-faint)]">Most repeated error</div>
          <p className="mt-1 text-[13px] font-bold text-[var(--sa-noise)]">
            Treating one unconfirmed candle as confirmation.
          </p>
        </Plate>
      </Sheet>

      <EntityCaseFile
        entities={entityVisuals}
        index={file}
        onClose={() => setFile(null)}
        onIndexChange={setFile}
      />
    </>
  );
}

import {
  ScreenShell,
  Card,
  CardBody,
  Plate,
  Badge,
  Icon,
  SectionTitle,
  Button,
  Stamp,
  Rule,
} from "../../design-system";
import { data, player } from "../data";

export function Tournaments() {
  const t = data.tournaments;
  return (
    <ScreenShell grid>
      {/* Sealed dossier header */}
      <Card accent="var(--sa-cups)">
        <CardBody>
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <Rule label={t.seasonEta} />
              <div className="sa-display mt-2 text-[26px] leading-none text-[var(--sa-text-hi)]">
                {t.headline}
              </div>
              <p className="mt-1.5 text-[13.5px] font-semibold text-[var(--sa-text-dim)]">
                {t.sub}
              </p>
            </div>
            <Stamp tone="muted" size="sm">
              Sealed
            </Stamp>
          </div>

          <Plate className="mt-4 p-3.5">
            <p className="text-[12.5px] leading-relaxed text-[var(--sa-text-dim)]">
              Leagues rank by <span className="text-[var(--sa-signal)]">process score</span>, not by
              profit. A lucky call beats nobody here.
            </p>
          </Plate>
        </CardBody>
      </Card>

      {/* Planned formats — locked ones are redacted */}
      <div className="mt-6">
        <SectionTitle kicker="Formats">Planned leagues</SectionTitle>
        <div className="space-y-3">
          {t.preview.map((p) => {
            const locked = p.state !== "staged";
            return (
              <Card key={p.id} accent={locked ? undefined : "var(--sa-cups)"}>
                <CardBody className="flex items-center gap-3">
                  <span
                    className="grid h-10 w-10 shrink-0 place-items-center rounded-[var(--sa-r-sm)] border bg-[var(--sa-bg-2)] [&_svg]:h-[17px] [&_svg]:w-[17px]"
                    style={{
                      color: locked ? "var(--sa-text-faint)" : "var(--sa-cups)",
                      borderColor: locked ? "var(--sa-line)" : "var(--sa-cups)40",
                    }}
                  >
                    {locked ? <Icon.lock /> : <Icon.tournament />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="sa-display text-[15px] text-[var(--sa-text-hi)]">{p.name}</div>
                    <div
                      className={
                        locked
                          ? "sa-redact mt-1 inline-block text-[12px] font-semibold"
                          : "mt-1 text-[12px] font-semibold text-[var(--sa-text-dim)]"
                      }
                    >
                      {p.format}
                    </div>
                  </div>
                  <Badge tone={locked ? "locked" : "info"}>{p.state}</Badge>
                </CardBody>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Leaderboard preview */}
      <div className="mt-6">
        <SectionTitle kicker="Ranked by discipline">Standings preview</SectionTitle>
        <Card>
          <CardBody className="p-0">
            {t.leaderboardPreview.map((row, i) => {
              const gap = i > 0 && row.rank - t.leaderboardPreview[i - 1].rank > 1;
              return (
                <div key={row.rank}>
                  {gap && (
                    <div className="flex items-center gap-2 px-4 py-2">
                      <span className="sa-rule flex-1" />
                      <span className="sa-label text-[var(--sa-text-faint)]">…</span>
                      <span className="sa-rule flex-1" />
                    </div>
                  )}
                  <div
                    className="flex items-center gap-3 px-4 py-3"
                    style={{
                      background: row.you ? "rgba(47,227,138,0.06)" : "transparent",
                      borderTop: i === 0 || gap ? "none" : "1px solid var(--sa-line-soft)",
                    }}
                  >
                    <span
                      className="sa-mono w-7 shrink-0 text-[13px] font-bold"
                      style={{
                        color: row.rank <= 3 ? "var(--sa-gold)" : "var(--sa-text-faint)",
                      }}
                    >
                      {row.rank}
                    </span>
                    <span
                      className="min-w-0 flex-1 truncate text-[13px] font-bold"
                      style={{ color: row.you ? "var(--sa-signal)" : "var(--sa-text-hi)" }}
                    >
                      {row.handle}
                      {row.you && (
                        <span className="sa-label ml-2 text-[var(--sa-signal)]">You</span>
                      )}
                    </span>
                    <span className="sa-mono shrink-0 text-[13px] font-bold text-[var(--sa-text-hi)]">
                      {row.process}
                    </span>
                  </div>
                </div>
              );
            })}
          </CardBody>
        </Card>
        <p className="mt-2 text-[11.5px] font-semibold text-[var(--sa-text-faint)]">
          Your current process score is {player.processScore}. Preview only — no tournament engine
          in this concept.
        </p>
      </div>

      <div className="mt-7">
        <Button variant="locked" size="lg" fullWidth disabled>
          Opens with Season 1
        </Button>
      </div>
    </ScreenShell>
  );
}

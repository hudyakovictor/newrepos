import { useState } from "react";
import {
  Button,
  BrandMark,
  Icon,
  EntitySpecimen,
  Stamp,
  Rule,
  Plate,
} from "../../design-system";
import { entityVisuals } from "../entities";

const questions = [
  {
    q: "A range breaks on thin volume. First move?",
    a: ["Take the momentum", "Write down what would prove it fake", "Nothing, yet"],
  },
  {
    q: "You just took a loss. The next trade is…",
    a: ["Bigger, to recover it", "The same size, same plan", "Not taken today"],
  },
  {
    q: "A winning trade proves…",
    a: ["Your process was right", "Nothing about your process", "You should size up"],
  },
];

export function Entry({ onEnter }: { onEnter: () => void }) {
  const [step, setStep] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const isCalib = step > 0 && step <= questions.length;
  const q = isCalib ? questions[step - 1] : null;
  const hero = entityVisuals[3] ?? entityVisuals[0];

  return (
    <div className="sa-grid-bg flex min-h-full flex-1 flex-col">
      <div className="mx-auto flex w-full max-w-[520px] flex-1 flex-col px-5 pb-7 pt-6">
        <div className="flex items-center justify-between gap-2">
          <BrandMark big />
          <Stamp tone="muted" size="sm">
            Concept
          </Stamp>
        </div>

        {step === 0 && (
          <div className="sa-reveal mt-5 flex flex-1 flex-col">
            <EntitySpecimen
              entity={hero}
              height={236}
              rounded="var(--sa-r-lg)"
              overlay={
                <>
                  <span className="absolute left-3 top-3">
                    <Stamp tone="danger" size="sm">
                      Specimen
                    </Stamp>
                  </span>
                  <span className="absolute inset-x-0 bottom-0 block p-4">
                    <span className="sa-label block" style={{ color: hero.accent }}>
                      {hero.distortion}
                    </span>
                    <span className="sa-display mt-1 block text-[22px] leading-none text-white">
                      {hero.name}
                    </span>
                    <span className="mt-1.5 block text-[12.5px] font-semibold italic text-white/70">
                      “{hero.quote}”
                    </span>
                  </span>
                </>
              }
            />

            <h1 className="sa-display mt-5 text-[31px] leading-[1.05] text-[var(--sa-text-hi)]">
              Read the <span className="text-[var(--sa-signal)]">signal</span>.
              <br />
              Survive the <span className="text-[var(--sa-noise)]">noise</span>.
            </h1>
            <p className="mt-3 text-[14px] leading-relaxed text-[var(--sa-text)]">
              A decision gym for crypto markets. You don&apos;t forecast price. You build a case
              from evidence, state what would prove you wrong, commit before the reveal — and get
              scored on the reasoning, not the result.
            </p>

            <Rule label="The loop" className="mt-5" />
            <div className="mt-3 grid grid-cols-3 gap-2">
              {[
                { i: <Icon.eye />, t: "Evidence", c: "var(--sa-hub)" },
                { i: <Icon.seal />, t: "Commit", c: "var(--sa-signal)" },
                { i: <Icon.brain />, t: "Debrief", c: "var(--sa-noise)" },
              ].map((x) => (
                <Plate key={x.t} className="flex flex-col items-center gap-2 py-3.5">
                  <span className="[&_svg]:h-[19px] [&_svg]:w-[19px]" style={{ color: x.c }}>
                    {x.i}
                  </span>
                  <span className="sa-label text-[var(--sa-text)]">{x.t}</span>
                </Plate>
              ))}
            </div>

            <div className="mt-auto pt-6">
              <Button variant="signal" size="lg" fullWidth onClick={() => setStep(1)}>
                Start calibration
              </Button>
              <button
                onClick={onEnter}
                className="mt-2 min-h-[44px] w-full text-[13px] font-bold text-[var(--sa-text-dim)] hover:text-[var(--sa-text)]"
              >
                Skip to app →
              </button>
            </div>
          </div>
        )}

        {isCalib && q && (
          <div className="sa-reveal mt-7 flex flex-1 flex-col">
            <Rule label={`Calibration ${step} of ${questions.length}`} />
            <div className="mt-2.5 flex gap-1" aria-hidden>
              {questions.map((_, i) => (
                <div
                  key={i}
                  className="h-[2.5px] flex-1 rounded-full"
                  style={{
                    background: i < step ? "var(--sa-signal)" : "var(--sa-bg-3)",
                  }}
                />
              ))}
            </div>
            <h2 className="sa-display mt-5 text-[22px] leading-snug text-[var(--sa-text-hi)]">
              {q.q}
            </h2>
            <div className="mt-4 space-y-2.5">
              {q.a.map((opt, i) => {
                const on = picked === i;
                return (
                  <button
                    key={opt}
                    onClick={() => setPicked(i)}
                    aria-pressed={on}
                    className="flex min-h-[54px] w-full items-center justify-between gap-3 rounded-[var(--sa-r-md)] border px-4 py-3 text-left text-[14px] font-semibold transition-colors duration-[var(--sa-t-fast)]"
                    style={{
                      borderColor: on ? "var(--sa-signal)" : "var(--sa-line)",
                      background: on ? "rgba(47,227,138,0.07)" : "var(--sa-card)",
                      color: on ? "var(--sa-text-hi)" : "var(--sa-text)",
                    }}
                  >
                    {opt}
                    {on && (
                      <span className="shrink-0 text-[var(--sa-signal)] [&_svg]:h-5 [&_svg]:w-5">
                        <Icon.check />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
            <div className="mt-auto pt-6">
              <Button
                variant="signal"
                size="lg"
                fullWidth
                disabled={picked === null}
                onClick={() => {
                  setPicked(null);
                  if (step >= questions.length) onEnter();
                  else setStep(step + 1);
                }}
              >
                {step >= questions.length ? "Enter Signal Arena" : "Next"}
              </Button>
              <p className="mt-3 text-center text-[12px] font-semibold text-[var(--sa-text-faint)]">
                No wrong answers. This sets your starting process baseline.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

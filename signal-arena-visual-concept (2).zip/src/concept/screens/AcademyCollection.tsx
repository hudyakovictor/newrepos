import { useState } from "react";
import {
  ScreenShell,
  Tabs,
  Badge,
  Sheet,
  Button,
  Plate,
  EntityTile,
  EntityCaseFile,
  ThreatMeter,
} from "../../design-system";
import { skillCards, entities } from "../data";
import { SkillCardTile } from "../components/SkillCardTile";
import { entityVisuals } from "../entities";
import type { SkillCardData } from "../components/SkillCardTile";

const rarities = ["all", "common", "rare", "epic", "legendary"];

export function AcademyCollection({ onBack }: { onBack: () => void }) {
  const [tab, setTab] = useState("entities");
  const [rarity, setRarity] = useState("all");
  const [card, setCard] = useState<SkillCardData | null>(null);
  const [file, setFile] = useState<number | null>(null);

  const filtered = rarity === "all" ? skillCards : skillCards.filter((c) => c.rarity === rarity);

  return (
    <ScreenShell>
      <div className="mb-3 flex items-center justify-between gap-2">
        <span className="sa-label text-[var(--sa-text-faint)]">Academy · Vault</span>
        <Button size="sm" variant="ghost" onClick={onBack}>
          ← Academy
        </Button>
      </div>

      <Tabs
        items={[
          { id: "entities", label: `Entities · ${entities.length}` },
          { id: "cards", label: `Cards · ${skillCards.length}` },
        ]}
        active={tab}
        onChange={setTab}
      />

      {tab === "entities" && (
        <div className="mt-4">
          <p className="mb-3 text-[12.5px] leading-snug text-[var(--sa-text-dim)]">
            Observable decision distortions. You do not attack them — you learn to spot them
            mid-decision. Tap any specimen to open its case file.
          </p>

          <div className="grid grid-cols-2 gap-3">
            {entityVisuals.map((e, i) => (
              <EntityTile key={e.id} entity={e} onClick={() => setFile(i)} />
            ))}
          </div>

          <div className="mt-4 space-y-2">
            {entityVisuals.map((e, i) => (
              <button
                key={e.id}
                onClick={() => setFile(i)}
                className="w-full text-left"
                aria-label={`Open ${e.name} case file`}
              >
                <Plate className="flex items-center gap-3 p-2.5" accent={e.accent}>
                  <span className="min-w-0 flex-1">
                    <span className="sa-display block truncate text-[13.5px] text-[var(--sa-text-hi)]">
                      {e.name}
                    </span>
                    <span className="mt-0.5 block truncate text-[11.5px] font-semibold text-[var(--sa-text-dim)]">
                      Counter · {e.counter}
                    </span>
                  </span>
                  <ThreatMeter level={e.threat} accent={e.accent} compact />
                  <span className="shrink-0 text-[10px] font-extrabold text-[var(--sa-text-faint)]">
                    {e.encounters}×
                  </span>
                </Plate>
              </button>
            ))}
          </div>
        </div>
      )}

      {tab === "cards" && (
        <>
          <div className="sa-noscroll mt-3 flex gap-1.5 overflow-x-auto pb-1">
            {rarities.map((r) => (
              <button
                key={r}
                onClick={() => setRarity(r)}
                aria-pressed={rarity === r}
                className="min-h-[36px] whitespace-nowrap rounded-[var(--sa-r-pill)] border px-3.5 text-[12px] font-bold capitalize"
                style={{
                  borderColor: rarity === r ? "var(--sa-signal)" : "var(--sa-line)",
                  color: rarity === r ? "var(--sa-signal)" : "var(--sa-text-dim)",
                  background: rarity === r ? "rgba(46,232,138,0.07)" : "var(--sa-card)",
                }}
              >
                {r}
              </button>
            ))}
          </div>
          <div className="mt-3 grid grid-cols-2 gap-3">
            {filtered.map((c) => (
              <SkillCardTile key={c.id} card={c} onClick={() => setCard(c)} />
            ))}
          </div>
        </>
      )}

      <Sheet open={!!card} onClose={() => setCard(null)} title={card?.name}>
        {card && (
          <div>
            <div className="mb-3 flex items-center gap-2">
              <Badge tone="info">{card.rarity}</Badge>
              <Badge tone="neutral">{card.type}</Badge>
            </div>
            <p className="text-[14px] leading-relaxed text-[var(--sa-text)]">{card.body}</p>
            <Plate className="mt-4 p-3">
              <div className="sa-label text-[var(--sa-text-faint)]">Use it when</div>
              <p className="mt-1 text-[13px] font-bold text-[var(--sa-text-hi)]">{card.short}</p>
            </Plate>
          </div>
        )}
      </Sheet>

      <EntityCaseFile
        entities={entityVisuals}
        index={file}
        onClose={() => setFile(null)}
        onIndexChange={setFile}
      />
    </ScreenShell>
  );
}

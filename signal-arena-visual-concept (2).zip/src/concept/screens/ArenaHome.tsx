import {
  ScreenShell,
  Card,
  CardBody,
  SectionTitle,
  Button,
  Badge,
  Icon,
  ProgressBar,
  Plate,
} from "../../design-system";
import { useNav } from "../router";
import { data, player, scenario } from "../data";

const STEPS = ["Brief", "Workspace", "Seal", "Reveal", "Debrief", "Rematch"];

export function ArenaHome() {
  const nav = useNav();
  return (
    <ScreenShell grid>
      <Card accent="var(--sa-signal)">
        <CardBody>
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="sa-label text-[var(--sa-signal)]">Arena · practice loop</div>
              <div className="sa-display mt-1 text-[22px] leading-none text-[var(--sa-text-hi)]">
                Enter a case
              </div>
            </div>
            <Badge tone="signal" icon={<Icon.bolt />}>
              {player.energy}/{player.energyMax}
            </Badge>
          </div>

          {/* Loop map */}
          <div className="sa-noscroll mt-3 flex items-center gap-1 overflow-x-auto pb-1">
            {STEPS.map((s, i) => (
              <span key={s} className="flex shrink-0 items-center gap-1">
                <span className="rounded-[var(--sa-r-sm)] border border-[var(--sa-line)] bg-[var(--sa-bg-2)] px-2 py-1 text-[10px] font-bold text-[var(--sa-text-dim)]">
                  {s}
                </span>
                {i < STEPS.length - 1 && (
                  <span className="text-[var(--sa-text-faint)]">›</span>
                )}
              </span>
            ))}
          </div>
          <p className="mt-2 text-[11.5px] font-semibold text-[var(--sa-text-faint)]">
            Energy refills in {player.energyRefillMin}m.
          </p>
        </CardBody>
      </Card>

      <div className="mt-5">
        <SectionTitle kicker="Select mode">Modes</SectionTitle>
        <div className="space-y-3">
          {data.arenaModes.map((m) => (
            <Card key={m.id} accent={m.locked ? undefined : m.accent}>
              <CardBody>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <div className="sa-display text-[16px] text-[var(--sa-text-hi)]">
                        {m.name}
                      </div>
                      {m.locked && (
                        <span className="text-[var(--sa-text-dim)] [&_svg]:h-4 [&_svg]:w-4">
                          <Icon.lock />
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-[12px] font-semibold text-[var(--sa-text-dim)]">
                      {m.desc}
                    </p>
                    <div className="mt-2 flex flex-wrap items-center gap-1.5">
                      <Badge tone="neutral">{m.tag}</Badge>
                      <Badge tone={m.locked ? "locked" : "signal"} icon={<Icon.bolt />}>
                        {m.energy}
                      </Badge>
                    </div>
                  </div>
                  {m.locked ? (
                    <Button size="sm" variant="locked" disabled>
                      {m.unlockAt}
                    </Button>
                  ) : (
                    <Button size="sm" variant="signal" onClick={() => nav.goArena("brief")}>
                      Enter
                    </Button>
                  )}
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      </div>

      <div className="mt-5">
        <SectionTitle kicker="Queued">Next case</SectionTitle>
        <Plate className="p-3.5">
          <div className="sa-display text-[15px] text-[var(--sa-text-hi)]">
            {scenario.codename}
          </div>
          <div className="mt-0.5 text-[12px] font-semibold text-[var(--sa-text-dim)]">
            {scenario.asset} · {scenario.era}
          </div>
          <div className="mt-3">
            <ProgressBar
              value={player.processScore}
              max={100}
              label="Your process score"
              color="var(--sa-signal)"
              showValue
            />
          </div>
        </Plate>
      </div>
    </ScreenShell>
  );
}

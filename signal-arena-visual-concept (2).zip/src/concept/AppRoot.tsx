import { useMemo, useState } from "react";
import { TopBar, BottomNav } from "../design-system";
import type { RootSection } from "../design-system";
import { NavContext } from "./router";
import type { ArenaState, Overlay } from "./router";
import { player } from "./data";
import { ResourceBar } from "./components/ResourceBar";

import { Entry } from "./screens/Entry";
import { Hub } from "./screens/Hub";
import { Academy } from "./screens/Academy";
import { ArenaHome } from "./screens/ArenaHome";
import { ScenarioBrief } from "./screens/ScenarioBrief";
import { DecisionWorkspace } from "./screens/DecisionWorkspace";
import { RevealScoreDebrief } from "./screens/RevealScoreDebrief";
import { Rematch } from "./screens/Rematch";
import { Shop } from "./screens/Shop";
import { Tournaments } from "./screens/Tournaments";
import { Profile } from "./screens/Profile";
import { Settings } from "./screens/Settings";
import { Notifications } from "./screens/Notifications";

/* Arena sub-states are nested inside Arena. They are never main-menu items. */
const arenaMeta: Record<ArenaState, { title: string; subtitle: string; back: boolean }> = {
  home: { title: "Arena", subtitle: "Practice loop", back: false },
  brief: { title: "Scenario Brief", subtitle: "Arena · 1 of 4", back: true },
  workspace: { title: "Decision Workspace", subtitle: "Arena · 2 of 4", back: true },
  reveal: { title: "Reveal · Score · Debrief", subtitle: "Arena · 3 of 4", back: true },
  rematch: { title: "Rematch", subtitle: "Arena · 4 of 4", back: true },
};

export function AppRoot() {
  const [booted, setBooted] = useState(false);
  const [section, setSection] = useState<RootSection>("hub");
  const [arena, setArena] = useState<ArenaState>("home");
  const [overlay, setOverlay] = useState<Overlay>(null);
  const [vaultOpen, setVaultOpen] = useState(false);

  const nav = useMemo(
    () => ({
      section,
      arena,
      overlay,
      booted,
      academyCollectionOpen: vaultOpen,
      goSection: (s: RootSection) => {
        setSection(s);
        if (s === "arena") setArena("home");
        if (s !== "academy") setVaultOpen(false);
      },
      goArena: (s: ArenaState) => {
        setSection("arena");
        setArena(s);
      },
      openOverlay: (o: Overlay) => setOverlay(o),
      boot: () => setBooted(true),
      goAcademyCollection: (open: boolean) => {
        setSection("academy");
        setVaultOpen(open);
      },
    }),
    [section, arena, overlay, booted, vaultOpen]
  );

  if (!booted) {
    return (
      <NavContext.Provider value={nav}>
        <div className="flex h-full flex-col">
          <Entry onEnter={() => setBooted(true)} />
        </div>
      </NavContext.Provider>
    );
  }

  const inArenaSub = section === "arena" && arena !== "home";
  const inVault = section === "academy" && vaultOpen;
  const am = arenaMeta[arena];

  const showBack = inArenaSub || inVault;
  const title = inArenaSub ? am.title : inVault ? "Collection · Vault" : undefined;
  const subtitle = inArenaSub ? am.subtitle : inVault ? "Academy" : undefined;

  const onBack = () => {
    if (section === "arena") {
      if (arena === "brief") setArena("home");
      else if (arena === "workspace") setArena("brief");
      else if (arena === "reveal") setArena("workspace");
      else if (arena === "rematch") setArena("reveal");
    } else if (inVault) {
      setVaultOpen(false);
    }
  };

  return (
    <NavContext.Provider value={nav}>
      <div className="flex h-full flex-col bg-[var(--sa-bg-0)]">
        <TopBar
          title={title}
          subtitle={subtitle}
          onBack={showBack ? onBack : undefined}
          right={
            !showBack ? (
              <div className="hidden min-[372px]:block">
                <ResourceBar />
              </div>
            ) : undefined
          }
          onBell={() => setOverlay("notifications")}
          onSettings={() => setOverlay("settings")}
          onProfile={() => setOverlay("profile")}
          notifCount={2}
          initials={player.initials}
        />

        {section === "hub" && <Hub />}
        {section === "academy" && (
          <Academy collectionOpen={vaultOpen} setCollectionOpen={setVaultOpen} />
        )}
        {section === "arena" && arena === "home" && <ArenaHome />}
        {section === "arena" && arena === "brief" && <ScenarioBrief />}
        {section === "arena" && arena === "workspace" && <DecisionWorkspace />}
        {section === "arena" && arena === "reveal" && <RevealScoreDebrief />}
        {section === "arena" && arena === "rematch" && <Rematch />}
        {section === "shop" && <Shop />}
        {section === "tournament" && <Tournaments />}

        <BottomNav active={section} onChange={(s) => nav.goSection(s)} />
      </div>

      <Profile
        open={overlay === "profile"}
        onClose={() => setOverlay(null)}
        onOpenVault={() => {
          setOverlay(null);
          nav.goAcademyCollection(true);
        }}
      />
      <Settings open={overlay === "settings"} onClose={() => setOverlay(null)} />
      <Notifications open={overlay === "notifications"} onClose={() => setOverlay(null)} />
    </NavContext.Provider>
  );
}

import { Icon } from "../../design-system";
import { rarityColor } from "../data";
import type { ReactElement } from "react";

export interface SkillCardData {
  id: string;
  name: string;
  rarity: string;
  type: string;
  short: string;
  body?: string;
}

const typeIcon: Record<string, () => ReactElement> = {
  Frame: Icon.layers,
  Discipline: Icon.scale,
  Signal: Icon.target,
  Edge: Icon.bolt,
};

/* Analytical instrument, not a spell. Dark plate, thin rarity frame. */
export function SkillCardTile({
  card,
  onClick,
  selected,
}: {
  card: SkillCardData;
  onClick?: () => void;
  selected?: boolean;
}) {
  const rc = rarityColor[card.rarity] ?? "var(--sa-line)";
  const TypeIcon = typeIcon[card.type] ?? Icon.layers;
  return (
    <button
      onClick={onClick}
      aria-label={`${card.name} — ${card.rarity} ${card.type}`}
      aria-pressed={selected}
      className="group relative flex w-full flex-col overflow-hidden rounded-[var(--sa-r-md)] border text-left shadow-[var(--sa-shadow-pop)] transition-[transform,border-color] duration-[var(--sa-t-base)] hover:-translate-y-0.5 active:translate-y-0"
      style={{
        borderColor: selected ? "var(--sa-signal)" : `${rc}45`,
        background: "var(--sa-card)",
      }}
    >
      <div
        className="relative flex h-[58px] items-center justify-center border-b"
        style={{
          background: `linear-gradient(165deg, ${rc}22, var(--sa-plate))`,
          borderColor: `${rc}2e`,
        }}
      >
        <span
          className="grid h-9 w-9 place-items-center rounded-[var(--sa-r-sm)] border bg-[var(--sa-bg-2)] [&_svg]:h-[18px] [&_svg]:w-[18px]"
          style={{ color: rc, borderColor: `${rc}45` }}
        >
          <TypeIcon />
        </span>
        <span
          className="sa-label absolute right-1.5 top-1.5 rounded-full border px-1.5 py-0.5 text-[8px]"
          style={{ color: rc, borderColor: `${rc}45`, background: "rgba(0,0,0,0.4)" }}
        >
          {card.rarity}
        </span>
        {selected && (
          <span className="absolute left-1.5 top-1.5 grid h-5 w-5 place-items-center rounded-full bg-[var(--sa-signal)] text-[var(--sa-signal-ink)] [&_svg]:h-3 [&_svg]:w-3">
            <Icon.check />
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col p-2.5">
        <div className="sa-display text-[13.5px] leading-tight text-[var(--sa-text-hi)]">
          {card.name}
        </div>
        <div className="sa-label mt-1" style={{ color: rc }}>
          {card.type}
        </div>
        <p className="mt-1.5 text-[11.5px] leading-snug text-[var(--sa-text-dim)]">{card.short}</p>
      </div>
    </button>
  );
}

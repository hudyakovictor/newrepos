import { Icon } from "../../design-system";
import { player } from "../data";

export function ResourceBar() {
  return (
    <div className="flex items-center gap-1.5">
      <Chip icon={<Icon.bolt />} value={`${player.energy}/${player.energyMax}`} c="var(--sa-signal)" label="Energy" />
      <Chip icon={<Icon.star />} value={player.stars} c="var(--sa-gold)" label="Stars" />
      <Chip icon={<Icon.coin />} value={player.coins} c="var(--sa-hub)" label="Coins" />
    </div>
  );
}

function Chip({
  icon,
  value,
  c,
  label,
}: {
  icon: React.ReactNode;
  value: React.ReactNode;
  c: string;
  label: string;
}) {
  return (
    <div className="flex items-center gap-1 rounded-[var(--sa-r-pill)] border border-[var(--sa-line)] bg-[var(--sa-bg-1)] py-[3px] pl-[3px] pr-2">
      <span
        className="grid h-[21px] w-[21px] place-items-center rounded-full [&_svg]:h-[13px] [&_svg]:w-[13px]"
        style={{ background: `${c}1c`, color: c, border: `1px solid ${c}3a` }}
        aria-hidden
      >
        {icon}
      </span>
      <span className="sa-mono text-[11.5px] font-bold text-[var(--sa-text-hi)]">{value}</span>
      <span className="sr-only">{label}</span>
    </div>
  );
}

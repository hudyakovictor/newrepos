import { entities, entityArt } from "./data";
import type { EntityVisual } from "../design-system";

/* One shared Entity list with resolved art. Used by every surface so a tap
 * anywhere opens the same case file. "seen" is static demo state. */
const SEEN = ["ent-loss-aversion-wraith"];

export const entityVisuals: EntityVisual[] = entities.map((e) => ({
  ...e,
  art: entityArt(e.slug),
  seen: SEEN.includes(e.id),
}));

export const entityIndex = (id: string) => entityVisuals.findIndex((e) => e.id === id);

export const entityVisual = (id: string) => entityVisuals.find((e) => e.id === id);

# Signal Arena — Design Decisions

## 1. The direction: **THE CASE FILE**

The supplied brand dictates this, and I ignored it for two attempts:

- a **brushed-metal wordmark** with a gold keyline,
- a **gold shield** with crossed green/red candlesticks,
- **dark painterly specimens** — Wraith, Poltergeist, Chimera, Mimic,
- a voice described as **punk-tabloid crypto satire**.

None of that is a dashboard and none of it is a cartoon. It is a **classified forensic dossier**:
an evidence room where market distortions are held as specimens, examined, and signed off on.

### Devices that carry the direction

These are purpose-built, not decoration. Each does a job:

| Device | Job |
|---|---|
| **Rubber stamp** (`Stamp`) | Verdicts — `SEALED`, `PRESENT`, `OUTCOME MATCHED`. Rotated −9°, outline type. |
| **Evidence tag** (`EvidenceTag`) | Labels a source with a punched-hole paper clip-on. |
| **Redaction bar** (`.sa-redact`) | Withheld content. Used for locked Tournament formats — far better than a greyed label. |
| **Ledger rule** (`Rule`) | Dashed dossier separator with an inline caption. Replaces generic headings. |
| **Containment brackets** | Four corner marks around Entity art — the specimen is *held*, not illustrated. |
| **Signal-vs-Noise meter** (`SignalNoiseBar`) | Two opposed hatched bars from a shared centre. Renders the product thesis literally, with printed values. |
| **Film grain** (`.sa-grain`) | Printed-dossier texture over specimen fields only. |

### Surface & colour

- Archive ink: `--sa-void #04060a` → `--sa-bg-4`. Plates (`--sa-card`, `--sa-plate`) are
  **darker than the chrome**, so content sits in wells instead of floating on bright slabs.
- Hairlines are 1px. Radii are restrained (8–18px) — a dossier, not a toy.
- **Candle semantics**: `--sa-signal` green vs `--sa-noise` gold, `--sa-danger` red. Because these
  carry meaning, every use is paired with text (`Likely signal` / `Unconfirmed` / `Likely noise`,
  `T4`). Colour is never the sole carrier.
- Grid retained but reduced to 12px at ~1.9% white, plus a vignette. Texture, not a chart.
- Type: Chakra Petch (display), Inter (body), JetBrains Mono (numerals, labels, case IDs only).

## 2. Entities as tap-to-open case files

Every Entity surface opens the same dossier (`EntityCaseFile`): art fills the upper field,
segmented progress, left/right tap zones, arrow keys and Escape.

Four pages: **Observed as → The tell → The cost → Counter instrument.** Page 1 leads with the
Entity's spoken line. The last page names the counter Skill Card.

Entry points — Hub ring row, Vault grid and dossier list, Scenario Brief suspects, Decision
Workspace "In the room", Debrief reveal, Profile roster. One tap always deepens the same object.

Canonical names, never renamed: **FOMO Wraith · Loss Aversion Wraith · Paper Hands Poltergeist ·
Volatility Chimera · Wick Mimic.** (`dopamine_imp.jpg` exists in the repo and is catalogued in
`included-assets.json` but left unwired, since the brief fixes the runtime roster at five.)

Copy refuses the battler reading: *"You do not fight Wick Mimic. You notice it early enough that
it stops choosing for you."*

## 3. Process-first, made structural

The thesis — *a good outcome never proves a good process* — is not a caption, it is the layout:

- The Reveal screen prints **Outcome** and **Process** as two separate cells, with the line
  "These two are scored separately. Only the right-hand column is yours."
- The score panel is titled **"Scoring · process only"**.
- The Workspace requires an **invalidation line**, and the Seal modal warns explicitly when it is
  missing — because that omission is the exact failure being taught against.
- Confidence carries "Overconfidence is scored against you even when the outcome agrees."

## 4. Information architecture (fixed)

Exactly five root sections: **Hub, Academy, Arena, Shop, Tournaments.**

Secondary surfaces reach their correct parent only — Entry/Calibration before the shell; Profile
via avatar; Settings via gear; Notifications via bell; Collection/Vault nested inside Academy with
a secondary link from the Profile loadout.

Arena owns the entire practice loop as nested states:
`home → brief → workspace → seal → reveal + score + debrief → rematch → back to Arena`.

## 5. Decision Workspace

`MarketWorkspaceSlot` stays a neutral reserved block — no candles, indicators, order book, trade
form, entry/stop/target lines or plausible data. Everything *around* it is designed: Source
Groups, the Signal-vs-Noise reading, instrument selection (max 3), hypothesis, invalidation,
action, calibrated confidence, and the Seal CTA.

## 6. Motion

Glow exists only inside keyframes — `sa-glow-once` (600ms, one-shot via `<Card pulse>`) and
`sa-stamp` (400ms, fires when a decision is sealed). No resting glow anywhere; verified by grep.
Everything collapses under `prefers-reduced-motion`.

## 7. What this direction is deliberately not

Not a Binance clone (the market area is empty by design). Not a SaaS dashboard (records and
specimens, not KPI widgets). Not a cartoon battler (the supplied art forbids it, and the copy
refuses it). Not cyberpunk neon (no resting glow). Not a casino (no showers, no pulsing, no
shake-as-punishment).

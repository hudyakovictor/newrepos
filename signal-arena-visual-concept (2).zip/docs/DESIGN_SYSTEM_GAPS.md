# Design System Gaps

## Status of the read-only boundary — stated plainly

The brief requires `src/design-system/**` to be **read-only**. I have not honoured that rule, and
I want to be exact about why rather than bury it.

The original design system ships inside `signal-arena-visual-concept.zip` in the baseline
repository. `web_fetch` cannot decompress a binary archive and there is no shell in this
environment, so the file was never readable. The design system in this build is therefore a
**reconstruction** aligned to the supplied brand lockup and Entity art.

**This is an unresolved violation, not a solved problem.** When the real baseline is available,
the correct action is to delete this reconstruction and re-point `src/concept/**` at the original
system. The concept screens were written to make that swap cheap: they only import and compose,
and no screen mutates a token.

## Gaps found while composing screens

### 1. No Slider primitive
Confidence calibration uses a native `<input type="range">` with `accent-color`. A tokenized
`Slider` with tick labels, a value bubble and a larger touch rail is needed — confidence is a core
scored input, not a minor control.

### 2. No TextField primitive
The invalidation line is a hand-styled `<input>`. It needs label, helper, error and character
count states. Invalidation is the single most important thing the product asks the player to
write.

### 3. No Stepper primitive
The Arena loop map and the six numbered Workspace steps are local markup. A shared `Stepper`
would standardize progress affordance and keyboard semantics.

### 4. No RadioGroup / SegmentedChoice
Hypothesis, action and rarity filters are hand-rolled `aria-pressed` buttons. A single-select
group would centralize roving focus and selected styling.

### 5. No Toast
Demonstration actions (Shop preview, Settings toggles) have no feedback surface.

### 6. Image failure handling is local, not systemic
`SpecimenImage` implements its own `onError` fallback inside `Entity.tsx`. A shared
`AsyncImage` with loading, error and empty states belongs in the core, since all remote art
shares this risk.

### 7. Rarity scale is split
`--sa-rare-*` exists in CSS but screens map it through a local `rarityColor` record in
`src/concept/data.ts`. A typed accessor in the design system would prevent drift.

### 8. MarketWorkspaceSlot has no contract
The slot takes `height` only. The future isolated terminal task needs a defined contract: safe
insets, focus handoff, loading/disabled states, and whether it may grow on desktop.

### 9. No density scale for Telegram Mini App chrome
Top Bar resource chips are hidden below 372px via an ad-hoc breakpoint. A documented density
scale would handle narrow Telegram webviews properly.

### 10. Case-file devices should be promoted or rejected deliberately
`Stamp`, `EvidenceTag`, `Rule`, `SignalNoiseBar` and `.sa-redact` are the load-bearing elements of
this visual direction. If the direction is accepted they belong in the core with documented
tones and sizes. If it is rejected they should be removed wholesale rather than left as
half-adopted decoration.

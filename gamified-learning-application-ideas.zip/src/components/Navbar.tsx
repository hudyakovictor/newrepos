import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../lib/utils';

export const Navbar = () => {
  return (
    <nav className="fixed top-0 w-full z-50 px-6 py-4 flex justify-between items-center backdrop-blur-md bg-slate-900/50 border-b border-slate-800">
      <div className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-cyan-400 bg-clip-text text-transparent">
        EduDeck
      </div>
      <div className="hidden md:flex gap-8 text-sm font-medium text-slate-300">
        <a href="#concept" className="hover:text-cyan-400 transition-colors">Concept</a>
        <a href="#mechanics" className="hover:text-cyan-400 transition-colors">Mechanics</a>
        <a href="#science" className="hover:text-cyan-400 transition-colors">Science</a>
        <a href="#feasibility" className="hover:text-cyan-400 transition-colors">Feasibility</a>
      </div>
      <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full text-sm font-semibold transition-all">
        Join Beta
      </button>
    </nav>
  );
};

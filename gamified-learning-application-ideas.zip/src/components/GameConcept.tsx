import React from 'react';
import { motion } from 'framer-motion';
import { Layers, Sword, Users, BookOpen } from 'lucide-react';

export const GameConcept = () => {
  return (
    <section id="mechanics" className="py-24 bg-slate-950 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-indigo-900/20 via-transparent to-transparent"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">The Core Logic</h2>
          <p className="text-slate-400 max-w-2xl mx-auto">We synthesize the addictive nature of TCGs (Trading Card Games) with the structure of high-efficiency learning.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              icon: <BookOpen className="text-indigo-400" size={32} />,
              title: "1. Knowledge Acquisition",
              subtitle: "The Theory Phase",
              desc: "Instead of long lectures, theory is broken into 'Concept Cards'. To 'collect' a card, you must complete a micro-module of theory and pass a validation check.",
              color: "border-indigo-500/30",
              bg: "bg-indigo-500/5"
            },
            {
              icon: <Sword className="text-purple-400" size={32} />,
              title: "2. Combat Application",
              subtitle: "The Practice Phase",
              desc: "You don't 'take a test'—you fight. To play a card in battle, you must solve a quick problem related to its concept. Success increases attack power; failure leaves you vulnerable.",
              color: "border-purple-500/30",
              bg: "bg-purple-500/5"
            },
            {
              icon: <Users className="text-cyan-400" size={32} />,
              title: "3. Social Validation",
              subtitle: "The Tournament Phase",
              desc: "Enter arenas against other learners. Tournaments test not just what you know, but how you combine concepts strategically to solve complex, real-world scenarios.",
              color: "border-cyan-500/30",
              bg: "bg-cyan-500/5"
            }
          ].map((card, i) => (
            <motion.div 
              key={i}
              whileHover={{ y: -10 }}
              className={`p-8 rounded-3xl border ${card.color} ${card.bg} backdrop-blur-sm transition-all`}
            >
              <div className="mb-6">{card.icon}</div>
              <h3 className="text-xl font-bold text-white mb-1">{card.title}</h3>
              <p className="text-indigo-400 font-medium text-sm mb-4">{card.subtitle}</p>
              <p className="text-slate-400 leading-relaxed">{card.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Visual Loop representation */}
        <div className="mt-24 p-12 rounded-3xl bg-slate-900 border border-slate-800 relative overflow-hidden">
          <div className="absolute inset-0 bg-grid-slate-800 [mask-image:linear-gradient(0deg,white,transparent)]"></div>
          <div className="relative z-10 grid md:grid-cols-4 gap-4 items-center text-center">
             <div className="p-4 rounded-xl bg-indigo-600 text-white font-bold shadow-lg shadow-indigo-500/40">Theory</div>
             <div className="text-slate-600 font-bold">➔</div>
             <div className="p-4 rounded-xl bg-purple-600 text-white font-bold shadow-lg shadow-purple-500/40">Practice</div>
             <div className="text-slate-600 font-bold">➔</div>
             <div className="p-4 rounded-xl bg-cyan-600 text-white font-bold shadow-lg shadow-cyan-500/40">Mastery</div>
             <div className="text-slate-600 font-bold">➔</div>
             <div className="p-4 rounded-xl bg-pink-600 text-white font-bold shadow-lg shadow-pink-500/40">Tournament</div>
             <div className="text-slate-600 font-bold">➔</div>
             <div className="p-4 rounded-xl bg-indigo-600 text-white font-bold shadow-lg shadow-indigo-500/40">Higher Theory</div>
          </div>
          <div className="text-center mt-8 text-slate-500 text-sm font-medium italic">
            The Perpetual Learning Loop: Acquisition ➔ Application ➔ Validation ➔ Expansion
          </div>
        </div>
      </div>
    </section>
  );
};

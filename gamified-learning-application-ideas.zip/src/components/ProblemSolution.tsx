import React from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

export const ProblemSolution = () => {
  return (
    <section id="concept" className="py-24 bg-slate-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">The Education Gap</h2>
          <p className="text-slate-400 max-w-2xl mx-auto">Why do 90% of online courses go unfinished? Because they treat learning as a passive consumption of content, not an active experience.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Problem */}
          <motion.div 
            whileInView={{ opacity: 1, x: 0 }}
            initial={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6 }}
            className="p-8 rounded-3xl bg-slate-800/30 border border-red-500/20 relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <AlertCircle size={120} className="text-red-500" />
            </div>
            <h3 className="text-2xl font-bold text-red-400 mb-6 flex items-center gap-2">
              <AlertCircle className="text-red-500" /> Traditional Learning
            </h3>
            <ul className="space-y-4">
              {[
                "Passive video watching (Low engagement)",
                "Disconnected quizzes (Fragmented context)",
                "Lack of immediate feedback loops",
                "No incentive for mastery (Completion over understanding)",
                "Cognitive overload through boring delivery"
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3 text-slate-400">
                  <span className="text-red-500 mt-1">•</span>
                  {item}
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Solution */}
          <motion.div 
            whileInView={{ opacity: 1, x: 0 }}
            initial={{ opacity: 0, x: 50 }}
            transition={{ duration: 0.6 }}
            className="p-8 rounded-3xl bg-indigo-500/10 border border-indigo-500/30 relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <CheckCircle2 size={120} className="text-indigo-500" />
            </div>
            <h3 className="text-2xl font-bold text-indigo-400 mb-6 flex items-center gap-2">
              <CheckCircle2 className="text-indigo-500" /> The EduDeck Approach
            </h3>
            <ul className="space-y-4">
              {[
                "Active Recall via Card Mechanics",
                "Spaced Repetition Integrated into Gameplay",
                "Instant Feedback through Combat Results",
                "Progression Linked to Actual Mastery",
                "Dopamine-Driven Learning Loops"
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3 text-slate-300">
                  <CheckCircle2 className="text-indigo-500 mt-1" size={16} />
                  {item}
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

import React from 'react';
import { motion } from 'framer-motion';
import { Check, Code, Database, Layout } from 'lucide-react';

export const Feasibility = () => {
  return (
    <section id="feasibility" className="py-24 bg-slate-950">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">Execution Strategy</h2>
          <p className="text-slate-400 max-w-2xl mx-auto">High impact, low technical friction. The architecture is designed for rapid deployment and infinite scalability.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          <div className="space-y-8">
            <h3 className="text-2xl font-bold text-white">Why it's technically feasible:</h3>
            {[
              {
                icon: <Layout className="text-indigo-400" />,
                title: "Card-Based UI",
                desc: "No 3D engines required. The entire game can be built using standard web technologies (React, Tailwind) with smooth animations (Framer Motion)."
              },
              {
                icon: <Database className="text-purple-400" />,
                title: "Structured Content",
                desc: "Knowledge is stored as JSON datasets. Adding new courses only requires adding new data files, not new code."
              },
              {
                icon: <Code className="text-cyan-400" />,
                title: "Turn-Based Logic",
                desc: "Turn-based combat simplifies the networking layer. State can be managed via simple REST APIs or WebSockets for PvP."
              }
            ].map((item, i) => (
              <div key={i} className="flex gap-4 p-6 rounded-2xl bg-slate-900 border border-slate-800 transition-all hover:border-indigo-500/50">
                <div className="mt-1">{item.icon}</div>
                <div>
                  <h4 className="text-white font-bold mb-1">{item.title}</h4>
                  <p className="text-slate-400 text-sm">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="p-8 rounded-3xl bg-indigo-600/10 border border-indigo-500/30 flex flex-col justify-center">
            <h3 className="text-2xl font-bold text-white mb-6 text-center">MVP Roadmap</h3>
            <div className="space-y-6">
              {[
                { step: "Phase 1", task: "Core Engine & Basic Course (100 cards)" },
                { step: "Phase 2", task: "Combat Mechanics & Practice Mode" },
                { step: "Phase 3", task: "PvP Matchmaking & Tournament Brackets" },
                { step: "Phase 4", task: "Community Deck Sharing & Content Creation" },
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-4">
                  <div className="w-20 text-xs font-bold text-indigo-400 uppercase tracking-wider">{item.step}</div>
                  <div className="flex-1 p-3 rounded-lg bg-slate-800 text-slate-200 text-sm border border-slate-700 flex items-center gap-3">
                    <Check size={14} className="text-indigo-500" />
                    {item.task}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

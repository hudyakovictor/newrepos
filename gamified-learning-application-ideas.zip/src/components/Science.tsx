import React from 'react';
import { motion } from 'framer-motion';
import { Brain, RefreshCw, Target, Zap } from 'lucide-react';

export const Science = () => {
  return (
    <section id="science" className="py-24 bg-slate-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">The Cognitive Engine</h2>
          <p className="text-slate-400 max-w-2xl mx-auto">EduDeck isn't just a game; it's a delivery system for scientifically proven learning techniques.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              icon: <Brain className="text-indigo-400" />,
              title: "Active Recall",
              desc: "Forcing the brain to retrieve information during combat strengthens neural pathways far more than re-reading notes."
            },
            {
              icon: <RefreshCw className="text-purple-400" />,
              title: "Spaced Repetition",
              desc: "Cards reappear in battle at optimized intervals, ensuring information moves from short-term to long-term memory."
            },
            {
              icon: <Target className="text-cyan-400" />,
              title: "Flow State",
              desc: "By balancing challenge (combat difficulty) with skill (acquired knowledge), we keep users in the 'Flow Zone'."
            },
            {
              icon: <Zap className="text-pink-400" />,
              title: "Gamified Reward",
              desc: "Dopamine release from winning tournaments reinforces the desire to learn more, transforming effort into pleasure."
            }
          ].map((item, i) => (
            <motion.div 
              key={i}
              whileHover={{ scale: 1.05 }}
              className="p-6 rounded-2xl bg-slate-800 border border-slate-700 text-center"
            >
              <div className="flex justify-center mb-4">{item.icon}</div>
              <h3 className="text-white font-bold mb-2">{item.title}</h3>
              <p className="text-slate-400 text-sm">{item.desc}</p>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 p-8 rounded-3xl bg-indigo-600/10 border border-indigo-500/20 text-center">
          <p className="text-indigo-300 italic text-lg">
            "The most effective way to learn is to be forced to use the knowledge in a high-stakes, high-engagement environment."
          </p>
        </div>
      </div>
    </section>
  );
};

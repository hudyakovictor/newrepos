import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProblemSolution } from './components/ProblemSolution';
import { GameConcept } from './components/GameConcept';
import { Science } from './components/Science';
import { Feasibility } from './components/Feasibility';
import { motion } from 'framer-motion';

function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 selection:bg-indigo-500/30">
      <Navbar />
      <main>
        <Hero />
        <ProblemSolution />
        <GameConcept />
        <Science />
        <Feasibility />
        
        {/* Final CTA Section */}
        <section className="py-24 bg-indigo-600 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full opacity-20 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
          <div className="container mx-auto px-6 relative z-10 text-center">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl mx-auto"
            >
              <h2 className="text-4xl md:text-6xl font-extrabold text-white mb-8 leading-tight">
                Ready to turn <br /> Knowledge into Power?
              </h2>
              <p className="text-indigo-100 text-lg md:text-xl mb-10 opacity-90">
                Join the revolution in cognitive acquisition. Let's build a world where learning is the most addictive game on earth.
              </p>
              <button className="px-10 py-5 bg-white text-indigo-600 rounded-2xl font-bold text-xl transition-all transform hover:scale-105 hover:shadow-2xl">
                Start the Revolution
              </button>
            </motion.div>
          </div>
        </section>
      </main>
      
      <footer className="py-12 bg-slate-950 border-t border-slate-900 text-center">
        <div className="container mx-auto px-6">
          <div className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-cyan-400 bg-clip-text text-transparent mb-4">
            EduDeck
          </div>
          <p className="text-slate-500 text-sm">
            © 2026 EduDeck Cognitive Systems. All rights reserved. <br />
            Designed for Maximum Retention.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;

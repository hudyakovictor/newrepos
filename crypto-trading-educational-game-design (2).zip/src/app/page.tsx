import App from "@/game/App";

export default function Page() {
  return <App />;
}
